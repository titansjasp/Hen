<div align="center">

# HEN Cheats Collection

### The largest collection of PlayStation 4 and PlayStation 5 cheats.

**Search by game, Title ID or creator. Find the exact version you need. Download only the cheat file you want.**

<br>

<a href="https://hencheats.vercel.app/">
  <img src="https://img.shields.io/badge/BROWSE%20%26%20DOWNLOAD-HEN%20CHEATS%20COLLECTION-1f6feb?style=for-the-badge&logo=googlechrome&logoColor=white" alt="Browse the HEN Cheats Collection website">
</a>

<br><br>

<a href="https://hencheats.vercel.app/">
  <img src="HENCC-web.jpg" alt="HEN Cheats Collection website preview">
</a>

<sub><b>Click the preview to open the HEN Cheats Collection website.</b></sub>

<br><br>

[![PS4](https://img.shields.io/badge/PlayStation-4-003791?style=flat-square&logo=playstation&logoColor=white)](https://hencheats.vercel.app/)
[![PS5](https://img.shields.io/badge/PlayStation-5-003791?style=flat-square&logo=playstation&logoColor=white)](https://hencheats.vercel.app/)
[![Formats](https://img.shields.io/badge/Formats-JSON%20%7C%20MC4%20%7C%20SHN-24292f?style=flat-square)](https://hencheats.vercel.app/)
[![Website](https://img.shields.io/badge/Website-Live-238636?style=flat-square)](https://hencheats.vercel.app/)

> **Play Your Way.**

</div>

---

## Looking for cheats for a game?

### Use the website first

If you only need cheats for one game, you do **not** need to download the entire repository.

**[Open HEN Cheats Collection →](https://hencheats.vercel.app/)**

On the website you can:

- Search by **game title**, **Title ID** or **cheat creator**
- Filter by **PS4**, **PS5** or other supported platforms
- Filter by **JSON**, **MC4** and **SHN**
- Sort by **Featured**, **Recently added**, **Title A–Z** or **Most versions**
- See every available version for a game
- See the creator and format of each cheat file
- Read file-specific **notes** and **issue warnings**
- Download **individual cheat files** directly
- Save games to your **Favorites**
- Report a problem with a specific cheat file

The website is the fastest way to find out whether the collection contains cheats for the **exact game ID and version** you are running.

<p align="center">
  <a href="https://hencheats.vercel.app/"><b>Browse the cheat database at hencheats.vercel.app</b></a>
</p>

---

## Want the entire collection?

Download the full repository when you want the complete collection for your console or cheat engine.

1. Click the green **Code** button at the top of this repository.
2. Choose **Download ZIP**.

**[Download the complete collection as ZIP](https://github.com/TeeKay87/HEN-Cheats-Collection/archive/refs/heads/master.zip)**

The downloaded `cheats` folder is ready for **etaHEN**. It also contains `.bat` files that prepare the collection for other supported cheat engines.

---

## Installation

> [!IMPORTANT]
> Back up or rename your existing cheat folder before replacing files, especially if you have personal or manually edited cheats.

### GoldHEN / etaHEN

1. Download the full collection using the instructions above.
2. FTP into your PlayStation.
3. Back up, rename or remove your existing cheat folder:
   - **PS5 / etaHEN:** `/data/etaHEN/cheats`
   - **PS4 / GoldHEN:** `/user/data/GoldHEN/cheats`
4. Copy the `cheats` folder from this collection into the corresponding location.
5. Restart and re-jailbreak your PlayStation.

### Other cheat engines

1. Download and extract the full collection.
2. Run the `.bat` file that matches the cheat engine you want to use.
3. The script creates a `data` folder and places the cheat files in the required structure.
4. FTP into your PlayStation.
5. Copy the generated `data` folder to the same location as the existing `data` folder on your console.
6. Allow matching cheat files to be overwritten.

> [!CAUTION]
> **Do not delete the existing `data` folder from your PlayStation.** Merge the generated folder into it and overwrite only the matching files.

Restart and re-jailbreak the PlayStation after installing the cheats.

---

## Website or GitHub?

**Use the website** when you want to search the collection, compare versions, read notes, save favorites or download a specific cheat file.

**Use GitHub** when you want the complete collection, the repository history, installation files or the latest project changes.

### → [Browse HEN Cheats Collection](https://hencheats.vercel.app/)

---

## Version History

### October 2026

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-10-10 | ADDED | PPSA21703 | 01.016.107 | [Vampire Survivors](https://hencheats.vercel.app/game/PPSA21703/01.016.107) |
| 2026-10-10 | UPDATE | PPSA01340 | 01.005.000 | [Demon's Souls](https://hencheats.vercel.app/game/PPSA01340/01.005.000) |
| 2026-10-10 | UPDATE | PPSA01341 | 01.005.000 | [Demon's Souls](https://hencheats.vercel.app/game/PPSA01341/01.005.000) |
| 2026-10-10 | UPDATE | PPSA01342 | 01.005.000 | [Demon's Souls](https://hencheats.vercel.app/game/PPSA01342/01.005.000) |
| 2026-10-10 | UPDATE | PPSA28183 | 01.006.038 | [Assassin's Creed Black Flag Resynced](https://hencheats.vercel.app/game/PPSA28183/01.006.038) |
| 2026-10-09 | ADDED | PPSA30601 | 01.002.000 | [Resonance: A Plague Tale Legacy](https://hencheats.vercel.app/game/PPSA30601/01.002.000) |
| 2026-10-08 | ADDED | CUSA15038 | 01.05 | [La-Mulana 2](https://hencheats.vercel.app/game/CUSA15038/01.05) |
| 2026-10-07 | UPDATE | CUSA44317 | 01.05 | [Blasphemous 2](https://hencheats.vercel.app/game/CUSA44317/01.05) |
| 2026-10-05 | ADDED | PPSA16064 | 01.000.000 | [Minecraft Dungeons II](https://hencheats.vercel.app/game/PPSA16064/01.000.000) |
| 2026-10-05 | UPDATE | PPSA14251 | 01.006.000 | [Mafia: The Old Country](https://hencheats.vercel.app/game/PPSA14251/01.006.000) |
| 2026-10-05 | ADDED | PPSA28183 | 01.006.038 | [Assassin's Creed Black Flag Resynced](https://hencheats.vercel.app/game/PPSA28183/01.006.038) |
| 2026-10-04 | UPDATE | PPSA03671 | 01.001.005 | [Marvel's Wolverine](https://hencheats.vercel.app/game/PPSA03671/01.001.005) |
| 2026-10-04 | ADDED | CUSA44317 | 01.05 | [Blasphemous 2](https://hencheats.vercel.app/game/CUSA44317/01.05) |
| 2026-10-04 | ADDED | PPSA08668 | 01.080.000 | [Final Fantasy VII Rebirth](https://hencheats.vercel.app/game/PPSA08668/01.080.000) |
| 2026-10-04 | UPDATE | PPSA08666 | 01.080.000 | [Final Fantasy VII Rebirth](https://hencheats.vercel.app/game/PPSA08666/01.080.000) |
| 2026-10-04 | ADDED | CUSA01222 | 03.10 | [Street Fighter V](https://hencheats.vercel.app/game/CUSA01222/03.10) |
| 2026-10-03 | UPDATE | PPSA03671 | 01.001.005 | [Marvel's Wolverine](https://hencheats.vercel.app/game/PPSA03671/01.001.005) |
| 2026-10-03 | ADDED | PPSA15554 | 01.007.000 | [Dead Cells](https://hencheats.vercel.app/game/PPSA15554/01.007.000) |
| 2026-10-03 | ADDED | PPSA03671 | 01.001.005 | [Marvel's Wolverine](https://hencheats.vercel.app/game/PPSA03671/01.001.005) |
| 2026-10-01 | ADDED | PPSA11386 | 01.018.000 | [007 First Light](https://hencheats.vercel.app/game/PPSA11386/01.018.000) |
| 2026-10-01 | ADDED | PPSA27836 | 01.000.001 | [Onimusha: Way of the Sword](https://hencheats.vercel.app/game/PPSA27836/01.000.001) |

<details>
<summary><b>September 2026</b></summary>

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-09-29 | ADDED | PPSA01746 | 02.008.000 | [Kena: Bridge of Spirits](https://hencheats.vercel.app/game/PPSA01746/02.008.000) |
| 2026-09-29 | ADDED | PPSA21159 | 01.003.000 | [Silent Hill f](https://hencheats.vercel.app/game/PPSA21159/01.003.000) |
| 2026-09-27 | ADDED | PPSA15972 | 01.008.000 | [Dynasty Warriors: Origins](https://hencheats.vercel.app/game/PPSA15972/01.008.000) |
| 2026-09-26 | ADDED | CUSA03467 | 01.01 | [Earth Defense Force 4.1: The Shadow of New Despair](https://hencheats.vercel.app/game/CUSA03467/01.01) |
| 2026-09-26 | ADDED | CUSA57547 | 01.08 | [Call of Duty: Black Ops](https://hencheats.vercel.app/game/CUSA57547/01.08) |
| 2026-09-26 | UPDATE | CUSA26613 | 01.04 | [Grand Theft Auto III - The Definitive Edition](https://hencheats.vercel.app/game/CUSA26613/01.04) |
| 2026-09-25 | ADDED | PPSA25661 | 01.000.002 | [Deliver At All Costs](https://hencheats.vercel.app/game/PPSA25661/01.000.002) |
| 2026-09-22 | ADDED | PPSA21607 | 01.002.000 | [The Smurfs: Dreams](https://hencheats.vercel.app/game/PPSA21607/01.002.000) |
| 2026-09-21 | ADDED | PPSA02633 | 01.000.028 | [Street Fighter 6](https://hencheats.vercel.app/game/PPSA02633/01.000.028) |
| 2026-09-21 | ADDED | PPSA15552 | 01.005.000 | [Dead Cells](https://hencheats.vercel.app/game/PPSA15552/01.005.000) |
| 2026-09-18 | ADDED | PPSA01575 | 01.020.000 | [Avatar: Frontiers of Pandora](https://hencheats.vercel.app/game/PPSA01575/01.020.000) |
| 2026-09-18 | ADDED | PPSA01576 | 01.020.000 | [Avatar: Frontiers of Pandora](https://hencheats.vercel.app/game/PPSA01576/01.020.000) |
| 2026-09-18 | UPDATE | PPSA25286 | 01.000.151 | [Crimson Desert](https://hencheats.vercel.app/game/PPSA25286/01.000.151) |
| 2026-09-17 | ADDED | PPSA02199 | 01.003.000 | [Star Wars Jedi: Fallen Order](https://hencheats.vercel.app/game/PPSA02199/01.003.000) |
| 2026-09-16 | ADDED | PPSA10665 | 01.003.004 | [Final Fantasy XVI](https://hencheats.vercel.app/game/PPSA10665/01.003.004) |
| 2026-09-16 | UPDATE | PPSA04404 | 01.000.004 | [RESIDENT EVIL 7 biohazard](https://hencheats.vercel.app/game/PPSA04404/01.000.004) |
| 2026-09-12 | UPDATE | PPSA07230 | 01.012.000 | [Assassin's Creed Mirage](https://hencheats.vercel.app/game/PPSA07230/01.012.000) |
| 2026-09-08 | UPDATE | PPSA01981 | 01.011.000 | [Doom Eternal](https://hencheats.vercel.app/game/PPSA01981/01.011.000) |
| 2026-09-04 | ADDED | PPSA06927 | 01.007.000 | [Warhammer Age of Sigmar: Realms of Ruin](https://hencheats.vercel.app/game/PPSA06927/01.007.000) |
| 2026-09-03 | UPDATE | PPSA08135 | 01.000.008 | [Alone in the Dark](https://hencheats.vercel.app/game/PPSA08135/01.000.008) |
| 2026-09-02 | ADDED | CUSA04284 | 01.01 | [Resident Evil 5](https://hencheats.vercel.app/game/CUSA04284/01.01) |
| 2026-09-01 | ADDED | PPSA01494 | 01.050.000 | [Borderlands 4](https://hencheats.vercel.app/game/PPSA01494/01.050.000) |
| 2026-09-01 | ADDED | PPSA08260 | 01.007.000 | [Star Wars Outlaws](https://hencheats.vercel.app/game/PPSA08260/01.007.000) |
| 2026-09-01 | ADDED | PPSA03351 | 01.033.000 | [The Callisto Protocol](https://hencheats.vercel.app/game/PPSA03351/01.033.000) |

</details>

<details>
<summary><b>August 2026</b></summary>

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-08-31 | ADDED | PPSA05063 | 01.006.000 | [Steelrising](https://hencheats.vercel.app/game/PPSA05063/01.006.000) |
| 2026-08-30 | ADDED | PPSA16096 | 01.003.000 | [Visions of Mana](https://hencheats.vercel.app/game/PPSA16096/01.003.000) |
| 2026-08-30 | ADDED | PPSA07783 | 01.000.013 | [Star Wars Jedi: Survivor](https://hencheats.vercel.app/game/PPSA07783/01.000.013) |
| 2026-08-29 | ADDED | PPSA26344 | 01.512.000 | [Ghost of Yotei](https://hencheats.vercel.app/game/PPSA26344/01.512.000) |
| 2026-08-28 | ADDED | CUSA01615 | 01.30 | [Final Fantasy XV](https://hencheats.vercel.app/game/CUSA01615/01.30) |
| 2026-08-28 | ADDED | PPSA01417 | 01.013.002 | [Marvel's Spider-Man: Miles Morales](https://hencheats.vercel.app/game/PPSA01417/01.013.002) |
| 2026-08-28 | ADDED | PPSA15304 | 01.002.004 | [METAL GEAR SOLID Δ: SNAKE EATER](https://hencheats.vercel.app/game/PPSA15304/01.002.004) |
| 2026-08-28 | ADDED | PPSA24096 | 01.010.000 | [Cronos: The New Dawn](https://hencheats.vercel.app/game/PPSA24096/01.010.000) |
| 2026-08-28 | UPDATE | PPSA02530 | 01.200.000 | [Pragmata](https://hencheats.vercel.app/game/PPSA02530/01.200.000) |
| 2026-08-28 | UPDATE | PPSA07230 | 01.012.000 | [Assassin's Creed Mirage](https://hencheats.vercel.app/game/PPSA07230/01.012.000) |
| 2026-08-28 | UPDATE | PPSA07631 | 01.000.000 | [SAROS](https://hencheats.vercel.app/game/PPSA07631/01.000.000) |
| 2026-08-28 | UPDATE | PPSA08236 | 01.006.004 | [Immortals of Aveum](https://hencheats.vercel.app/game/PPSA08236/01.006.004) |
| 2026-08-28 | UPDATE | PPSA10664 | 01.003.004 | [Final Fantasy XVI](https://hencheats.vercel.app/game/PPSA10664/01.003.004) |
| 2026-08-28 | UPDATE | PPSA10872 | 01.008.000 | [Persona 3 Reload](https://hencheats.vercel.app/game/PPSA10872/01.008.000) |
| 2026-08-28 | UPDATE | PPSA20396 | 01.019.076 | [Assassin's Creed Shadows](https://hencheats.vercel.app/game/PPSA20396/01.019.076) |
| 2026-08-28 | UPDATE | PPSA25286 | 01.000.151 | [Crimson Desert](https://hencheats.vercel.app/game/PPSA25286/01.000.151) |
| 2026-08-28 | UPDATE | PPSA28336 | 01.009.000 | [S.T.A.L.K.E.R. 2: Heart of Chornobyl](https://hencheats.vercel.app/game/PPSA28336/01.009.000) |
| 2026-08-28 | UPDATE | PPSA31246 | 01.200.000 | [Resident Evil Requiem](https://hencheats.vercel.app/game/PPSA31246/01.200.000) |
| 2026-08-27 | UPDATE | PPSA09232 | 01.005.000 | [Ghost Song](https://hencheats.vercel.app/game/PPSA09232/01.005.000) |
| 2026-08-26 | ADDED | PPSA09232 | 01.005.000 | [Ghost Song](https://hencheats.vercel.app/game/PPSA09232/01.005.000) |
| 2026-08-26 | ADDED | PPSA04132 | 01.060.000 | [Samurai Maiden](https://hencheats.vercel.app/game/PPSA04132/01.060.000) |
| 2026-08-26 | UPDATE | PPSA17337 | 01.004.000 | [Space Adventure Cobra - The Awakening](https://hencheats.vercel.app/game/PPSA17337/01.004.000) |
| 2026-08-26 | ADDED | PPSA14251 | 01.008.000 | [Mafia: The Old Country](https://hencheats.vercel.app/game/PPSA14251/01.008.000) |
| 2026-08-26 | UPDATE | PPSA20447 | 01.021.003 | [The First Berserker: Khazan](https://hencheats.vercel.app/game/PPSA20447/01.021.003) |
| 2026-08-25 | ADDED | PPSA17942 | 01.001.000 | [Dragon Quest VII Reimagined](https://hencheats.vercel.app/game/PPSA17942/01.001.000) |
| 2026-08-25 | ADDED | PPSA17943 | 01.001.000 | [Dragon Quest VII Reimagined](https://hencheats.vercel.app/game/PPSA17943/01.001.000) |
| 2026-08-25 | UPDATE | PPSA03977 | 04.000.000 | [The Witcher 3: Wild Hunt: Complete Edition](https://hencheats.vercel.app/game/PPSA03977/04.000.000) |
| 2026-08-25 | UPDATE | PPSA07411 | 01.100.000 | [Resident Evil 4](https://hencheats.vercel.app/game/PPSA07411/01.100.000) |
| 2026-08-25 | UPDATE | PPSA07412 | 01.000.000 | [Resident Evil 4](https://hencheats.vercel.app/game/PPSA07412/01.000.000) |
| 2026-08-25 | UPDATE | PPSA08260 | 01.003.001 | [Star Wars Outlaws](https://hencheats.vercel.app/game/PPSA08260/01.003.001) |
| 2026-08-25 | UPDATE | PPSA20612 | 01.000.000 | [Dragon Quest III HD-2D Remake](https://hencheats.vercel.app/game/PPSA20612/01.000.000) |
| 2026-08-24 | UPDATE | PPSA03977 | 04.000.000 | [The Witcher 3: Wild Hunt: Complete Edition](https://hencheats.vercel.app/game/PPSA03977/04.000.000) |
| 2026-08-24 | UPDATE | PPSA07411 | 01.100.000 | [Resident Evil 4](https://hencheats.vercel.app/game/PPSA07411/01.100.000) |
| 2026-08-24 | UPDATE | PPSA07412 | 01.000.000 | [Resident Evil 4](https://hencheats.vercel.app/game/PPSA07412/01.000.000) |
| 2026-08-24 | UPDATE | PPSA08260 | 01.003.001 | [Star Wars Outlaws](https://hencheats.vercel.app/game/PPSA08260/01.003.001) |
| 2026-08-24 | UPDATE | PPSA20612 | 01.000.000 | [Dragon Quest III HD-2D Remake](https://hencheats.vercel.app/game/PPSA20612/01.000.000) |
| 2026-08-24 | ADDED | PPSA20447 | 01.021.003 | [The First Berserker: Khazan](https://hencheats.vercel.app/game/PPSA20447/01.021.003) |
| 2026-08-22 | ADDED | PPSA17599 | 01.500.300 | [Clair Obscur: Expedition 33](https://hencheats.vercel.app/game/PPSA17599/01.500.300) |
| 2026-08-22 | ADDED | PPSA09790 | 01.010.000 | [Dragon Ball FighterZ](https://hencheats.vercel.app/game/PPSA09790/01.010.000) |
| 2026-08-22 | UPDATE | PPSA01870 | 01.000.013 | [Far Cry 6](https://hencheats.vercel.app/game/PPSA01870/01.000.013) |
| 2026-08-22 | UPDATE | PPSA15210 | 02.013.000 | [Dragon Ball: Sparking! ZERO](https://hencheats.vercel.app/game/PPSA15210/02.013.000) |
| 2026-08-22 | ADDED | PPSA15210 | 02.013.000 | [Dragon Ball: Sparking! ZERO](https://hencheats.vercel.app/game/PPSA15210/02.013.000) |
| 2026-08-21 | ADDED | PPSA30803 | 01.200.000 | [Resident Evil Requiem](https://hencheats.vercel.app/game/PPSA30803/01.200.000) |
| 2026-08-21 | ADDED | PPSA31246 | 01.200.000 | [Resident Evil Requiem](https://hencheats.vercel.app/game/PPSA31246/01.200.000) |
| 2026-08-21 | ADDED | PPSA31327 | 01.015.000 | [Yakuza 0 Director's Cut](https://hencheats.vercel.app/game/PPSA31327/01.015.000) |
| 2026-08-21 | UPDATE | PPSA01460 | 01.015.001 | [Marvel's Spider-Man: Miles Morales](https://hencheats.vercel.app/game/PPSA01460/01.015.001) |
| 2026-08-20 | UPDATE | PPSA19534 | 01.000.016 | [Battlefield 6](https://hencheats.vercel.app/game/PPSA19534/01.000.016) |
| 2026-08-20 | ADDED | PPSA19534 | 01.000.016 | [Battlefield 6](https://hencheats.vercel.app/game/PPSA19534/01.000.016) |
| 2026-08-19 | ADDED | CUSA00740 | 01.41 | [Terraria](https://hencheats.vercel.app/game/CUSA00740/01.41) |
| 2026-08-19 | ADDED | PPSA21837 | 01.017.001 | [Lollipop Chainsaw RePOP](https://hencheats.vercel.app/game/PPSA21837/01.017.001) |
| 2026-08-19 | ADDED | PPSA01460 | 01.015.001 | [Marvel's Spider-Man: Miles Morales](https://hencheats.vercel.app/game/PPSA01460/01.015.001) |
| 2026-08-19 | UPDATE | PPSA13195 | 01.014.001 | [Stellar Blade](https://hencheats.vercel.app/game/PPSA13195/01.014.001) |
| 2026-08-19 | UPDATE | PPSA21203 | 01.512.105 | [The Elder Scrolls IV: Oblivion Remastered](https://hencheats.vercel.app/game/PPSA21203/01.512.105) |
| 2026-08-18 | ADDED | PPSA02484 | 01.023.001 | [Nioh Remastered - The Complete Edition](https://hencheats.vercel.app/game/PPSA02484/01.023.001) |
| 2026-08-18 | ADDED | PPSA02487 | 01.027.001 | [Nioh 2 Remastered - The Complete Edition](https://hencheats.vercel.app/game/PPSA02487/01.027.001) |
| 2026-08-18 | ADDED | PPSA03098 | 01.000.011 | [Dead Island 2](https://hencheats.vercel.app/game/PPSA03098/01.000.011) |
| 2026-08-16 | ADDED | PPSA06981 | 01.006.000 | [Naruto x Boruto: Ultimate Ninja Storm Connections](https://hencheats.vercel.app/#PPSA06981-01.006.000) |
| 2026-08-15 | ADDED | PPSA06438 | 01.001.140 | [Let's Build a Zoo](https://hencheats.vercel.app/#PPSA06438-01.001.140) |
| 2026-08-15 | ADDED | PPSA08666 | 01.080.000 | [Final Fantasy VII Rebirth](https://hencheats.vercel.app/#PPSA08666-01.080.000) |
| 2026-08-15 | ADDED | PPSA09384 | 01.000.000 | [The Caligula Effect: Overdose](https://hencheats.vercel.app/#PPSA09384-01.000.000) |
| 2026-08-15 | ADDED | PPSA10906 | 01.000.000 | [Atelier Marie Remake: The Alchemist of Salburg](https://hencheats.vercel.app/#PPSA10906-01.000.000) |
| 2026-08-15 | ADDED | PPSA14708 | 01.004.000 | [Commandos: Origins](https://hencheats.vercel.app/#PPSA14708-01.004.000) |
| 2026-08-15 | ADDED | PPSA17232 | 01.010.000 | [Sniper Elite: Resistance](https://hencheats.vercel.app/#PPSA17232-01.010.000) |
| 2026-08-15 | ADDED | PPSA22826 | 01.000.002 | [Tales of Berseria Remastered](https://hencheats.vercel.app/#PPSA22826-01.000.002) |
| 2026-08-15 | ADDED | PPSA21203 | 01.512.105 | [The Elder Scrolls IV: Oblivion Remastered](https://hencheats.vercel.app/#PPSA21203-01.512.105) |
| 2026-08-13 | ADDED | PPSA27366 | 01.000.025 | [AI Limit](https://hencheats.vercel.app/#PPSA27366-01.000.025) |
| 2026-08-13 | ADDED | PPSA03641 | 01.086.000 | [Lords of the Fallen](https://hencheats.vercel.app/#PPSA03641-01.086.000) |
| 2026-08-13 | ADDED | PPSA30223 | 01.015.000 | [Yakuza Kiwami 3 & Dark Ties](https://hencheats.vercel.app/#PPSA30223-01.015.000) |
| 2026-08-13 | UPDATE | PPSA23908 | 01.005.000 | [Code Vein II](https://hencheats.vercel.app/#PPSA23908-01.005.000) |
| 2026-08-11 | ADDED | PPSA14427 | 01.000.008 | [Crymachina Digital Deluxe Edition](https://hencheats.vercel.app/#PPSA14427-01.000.008) |
| 2026-08-11 | ADDED | PPSA21297 | 01.000.000 | [Withering Rooms](https://hencheats.vercel.app/#PPSA21297-01.000.000) |
| 2026-08-11 | UPDATE | PPSA04930 | 01.048.000 | [SnowRunner](https://hencheats.vercel.app/#PPSA04930-01.048.000) |
| 2026-08-09 | ADDED | PPSA29343 | 01.000.000 | [Beast of Reincarnation Digital Deluxe Edition](https://hencheats.vercel.app/#PPSA29343-01.000.000) |
| 2026-08-09 | UPDATE | PPSA29343 | 01.000.000 | [Beast of Reincarnation Digital Deluxe Edition](https://hencheats.vercel.app/#PPSA29343-01.000.000) |
| 2026-08-09 | ADDED | PPSA24203 | 02.000.000 | [The House of the Dead 2: Remake](https://hencheats.vercel.app/#PPSA24203-02.000.000) |
| 2026-08-08 | ADDED | PPSA20423 | 02.000.000 | [Another Crab's Treasure](https://hencheats.vercel.app/#PPSA20423-02.000.000) |
| 2026-08-07 | ADDED | PPSA07570 | 01.010.001 | [Mortal Kombat 1](https://hencheats.vercel.app/#PPSA07570-01.010.001) |
| 2026-08-06 | ADDED | PPSA29343 | 01.000.000 | [Beast of Reincarnation Digital Deluxe Edition](https://hencheats.vercel.app/#PPSA29343-01.000.000) |
| 2026-08-05 | ADDED | PPSA28465 | 01.006.000 | [Trails in the Sky 1st Chapter](https://hencheats.vercel.app/#PPSA28465-01.006.000) |
| 2026-08-05 | ADDED | PPSA10621 | 01.012.000 | [Lies of P](https://hencheats.vercel.app/#PPSA10621-01.012.000) |
| 2026-08-05 | ADDED | PPSA04452 | 01.012.002 | [Warhammer 40,000: Space Marine 2](https://hencheats.vercel.app/#PPSA04452-01.012.002) |
| 2026-08-04 | ADDED | PPSA03388 | 01.005.400 | [Atlas Fallen: Reign of Sand](https://hencheats.vercel.app/#PPSA03388-01.005.400) |
| 2026-08-04 | UPDATE | CUSA00265 | 02.35 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00265-02.35) |
| 2026-08-04 | UPDATE | CUSA00283 | 02.35 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00283-02.35) |
| 2026-08-04 | UPDATE | SLPS25233 | 01.00 | [DoDonPachi Dai-Ou-Jou](https://hencheats.vercel.app/#SLPS25233-01.00) |
| 2026-08-04 | ADDED | PPSA08587 | 01.004.002 | [Dragon Ball: Xenoverse 2](https://hencheats.vercel.app/#PPSA08587-01.004.002) |
| 2026-08-03 | ADDED | PPSA05214 | 01.004.000 | [Thymesia](https://hencheats.vercel.app/#PPSA05214-01.004.000) |
| 2026-08-02 | ADDED | PPSA26354 | 01.001.000 | [Triangle Strategy](https://hencheats.vercel.app/#PPSA26354-01.001.000) |
| 2026-08-02 | ADDED | PPSA26917 | 01.006.002 | [Mandragora: Whispers of the Witch Tree](https://hencheats.vercel.app/#PPSA26917-01.006.002) |
| 2026-08-02 | ADDED | PPSA17163 | 01.000.002 | [Jets'n'Guns 2](https://hencheats.vercel.app/#PPSA17163-01.000.002) |
| 2026-08-02 | ADDED | PPSA18528 | 01.009.000 | [Mighty Morphin Power Rangers: Rita's Rewind](https://hencheats.vercel.app/#PPSA18528-01.009.000) |
| 2026-08-02 | ADDED | PPSA22520 | 01.000.011 | [Animal Well](https://hencheats.vercel.app/#PPSA22520-01.000.011) |
| 2026-08-02 | ADDED | PPSA27625 | 01.000.000 | [FANTASY LIFE i: The Girl Who Steals Time](https://hencheats.vercel.app/#PPSA27625-01.000.000) |
| 2026-08-01 | ADDED | PPSA30568 | 01.000.000 | [Invincible VS](https://hencheats.vercel.app/#PPSA30568-01.000.000) |

</details>

<details>
<summary><b>July 2026</b></summary>

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-07-31 | ADDED | PPSA30138 | 01.000.001 | [Fast & Furious: Arcade Edition](https://hencheats.vercel.app/#PPSA30138-01.000.001) |
| 2026-07-31 | ADDED | PPSA30094 | 01.100.100 | [High on Life 2](https://hencheats.vercel.app/#PPSA30094-01.100.100) |
| 2026-07-31 | ADDED | PPSA11541 | 01.002.000 | [Story of Seasons: A Wonderful Life](https://hencheats.vercel.app/#PPSA11541-01.002.000) |
| 2026-07-31 | ADDED | PPSA20798 | 01.000.000 | [Ufouria: The Saga 2](https://hencheats.vercel.app/#PPSA20798-01.000.000) |
| 2026-07-31 | ADDED | PPSA23908 | 01.005.000 | [Code Vein II](https://hencheats.vercel.app/#PPSA23908-01.005.000) |
| 2026-07-30 | ADDED | PPSA32393 | 01.002.002 | [Total Chaos](https://hencheats.vercel.app/#PPSA32393-01.002.002) |
| 2026-07-30 | ADDED | PPSA01949 | 01.000.004 | [Control: Ultimate Edition](https://hencheats.vercel.app/#PPSA01949-01.000.004) |
| 2026-07-29 | ADDED | PPSA29629 | 02.002.000 | [Marvel Cosmic Invasion](https://hencheats.vercel.app/#PPSA29629-02.002.000) |
| 2026-07-29 | ADDED | PPSA02494 | 01.003.000 | [Doraemon Story of Seasons: Friends of the Great Kingdom](https://hencheats.vercel.app/#PPSA02494-01.003.000) |
| 2026-07-29 | ADDED | PPSA18189 | 01.000.004 | [Pac-Man World 2: Re-Pac](https://hencheats.vercel.app/#PPSA18189-01.000.004) |
| 2026-07-29 | ADDED | PPSA01687 | 01.026.000 | [Call of Duty: Vanguard](https://hencheats.vercel.app/#PPSA01687-01.026.000) |
| 2026-07-29 | ADDED | PPSA19461 | 01.200.000 | [Shinobi: Art of Vengeance](https://hencheats.vercel.app/#PPSA19461-01.200.000) |
| 2026-07-28 | ADDED | PPSA01932 | 01.000.000 | [In Sound Mind](https://hencheats.vercel.app/#PPSA01932-01.000.000) |
| 2026-07-28 | ADDED | PPSA04921 | 01.000.009 | [In Sound Mind](https://hencheats.vercel.app/#PPSA04921-01.000.009) |
| 2026-07-28 | ADDED | PPSA32802 | 01.002.002 | [Fatal Frame II: Crimson Butterfly Remake](https://hencheats.vercel.app/#PPSA32802-01.002.002) |
| 2026-07-28 | ADDED | PPSA07411 | 01.590.000 | [Resident Evil 4](https://hencheats.vercel.app/#PPSA07411-01.590.000) |
| 2026-07-27 | ADDED | PPSA04263 | 01.010.002 | [Grand Theft Auto V](https://hencheats.vercel.app/#PPSA04263-01.010.002) |
| 2026-07-27 | ADDED | PPSA04264 | 01.010.002 | [Grand Theft Auto V](https://hencheats.vercel.app/#PPSA04264-01.010.002) |
| 2026-07-27 | ADDED | PPSA02774 | 01.002.000 | [XIII](https://hencheats.vercel.app/#PPSA02774-01.002.000) |
| 2026-07-27 | ADDED | PPSA25428 | 01.007.000 | [Demon Slayer: Kimetsu no Yaiba: The Hinokami Chronicles 2](https://hencheats.vercel.app/#PPSA25428-01.007.000) |
| 2026-07-27 | ADDED | PPSA31977 | 01.000.000 | [Darksiders: Warmastered Edition](https://hencheats.vercel.app/#PPSA31977-01.000.000) |
| 2026-07-27 | ADDED | PPSA02527 | 01.000.005 | [Kitaria Fables](https://hencheats.vercel.app/#PPSA02527-01.000.005) |
| 2026-07-26 | ADDED | PPSA04203 | 01.000.019 | [Sid Meier's Civilization VII](https://hencheats.vercel.app/#PPSA04203-01.000.019) |
| 2026-07-26 | ADDED | PPSA03712 | 01.006.000 | [Puzzle Bobble 3D: Vacation Odyssey](https://hencheats.vercel.app/#PPSA03712-01.006.000) |
| 2026-07-26 | ADDED | PPSA28601 | 01.000.004 | [Steel Seed](https://hencheats.vercel.app/#PPSA28601-01.000.004) |
| 2026-07-25 | ADDED | PPSA28209 | 01.011.000 | [MindsEye](https://hencheats.vercel.app/#PPSA28209-01.011.000) |
| 2026-07-25 | ADDED | PPSA01461 | 01.013.002 | [Marvel's Spider-Man: Miles Morales](https://hencheats.vercel.app/#PPSA01461-01.013.002) |
| 2026-07-25 | ADDED | CUSA07865 | 01.00 | [MotoGP 17](https://hencheats.vercel.app/#CUSA07865-01.00) |
| 2026-07-25 | ADDED | CUSA05667 | 01.12 | [Rain World](https://hencheats.vercel.app/#CUSA05667-01.12) |
| 2026-07-25 | ADDED | PPSA15508 | 02.001.010 | [The Last of Us: Part II Remastered](https://hencheats.vercel.app/#PPSA15508-02.001.010) |
| 2026-07-25 | ADDED | PPSA26528 | 01.000.028 | [Code Violet](https://hencheats.vercel.app/#PPSA26528-01.000.028) |
| 2026-07-24 | ADDED | CUSA00318 | 01.01 | [MotoGP 14](https://hencheats.vercel.app/#CUSA00318-01.01) |
| 2026-07-24 | ADDED | PPSA28002 | 01.006.000 | [Ninja Gaiden: Ragebound](https://hencheats.vercel.app/#PPSA28002-01.006.000) |
| 2026-07-24 | ADDED | PPSA29714 | 02.000.013 | [BlazBlue Entropy Effect X](https://hencheats.vercel.app/#PPSA29714-02.000.013) |
| 2026-07-23 | ADDED | PPSA26356 | 01.002.000 | [BUBBLE BOBBLE Sugar Dungeons](https://hencheats.vercel.app/#PPSA26356-01.002.000) |
| 2026-07-23 | ADDED | CUSA02041 | 01.02 | [MotoGP 15](https://hencheats.vercel.app/#CUSA02041-01.02) |
| 2026-07-23 | ADDED | PPSA15368 | 01.000.003 | [Contra: Operation Galuga](https://hencheats.vercel.app/#PPSA15368-01.000.003) |
| 2026-07-23 | ADDED | PPSA01903 | 01.005.000 | [Final Fantasy VII Remake Intergrade](https://hencheats.vercel.app/#PPSA01903-01.005.000) |
| 2026-07-22 | ADDED | CUSA05164 | 01.01 | [Valentino Rossi The Game](https://hencheats.vercel.app/#CUSA05164-01.01) |
| 2026-07-21 | UPDATE | PPSA17525 | 01.008.001 | [Gears of War: Reloaded](https://hencheats.vercel.app/#PPSA17525-01.008.001) |
| 2026-07-21 | ADDED | PPSA21112 | 01.000.000 | [TEVI](https://hencheats.vercel.app/#PPSA21112-01.000.000) |
| 2026-07-20 | ADDED | PPSA20154 | 01.000.021 | [Revenge of the Savage Planet](https://hencheats.vercel.app/#PPSA20154-01.000.021) |
| 2026-07-20 | ADDED | PPSA22322 | 01.000.000 | [Dragon Quest I & II HD-2D Remake](https://hencheats.vercel.app/#PPSA22322-01.000.000) |
| 2026-07-20 | ADDED | CUSA23470 | 01.05 | [Crash Bandicoot 4: It's About Time](https://hencheats.vercel.app/#CUSA23470-01.05) |
| 2026-07-20 | ADDED | PPSA20289 | 02.000.000 | [Kong: Survivor Instinct](https://hencheats.vercel.app/#PPSA20289-02.000.000) |
| 2026-07-19 | ADDED | PPSA02182 | 01.024.000 | [Suicide Squad: Kill the Justice League](https://hencheats.vercel.app/#PPSA02182-01.024.000) |
| 2026-07-19 | ADDED | PPSA17337 | 01.004.000 | [Space Adventure Cobra - The Awakening](https://hencheats.vercel.app/#PPSA17337-01.004.000) |
| 2026-07-19 | ADDED | PPSA06568 | 01.000.000 | [Sword Art Online: Fractured Daydream](https://hencheats.vercel.app/#PPSA06568-01.000.000) |
| 2026-07-16 | ADDED | CUSA01671 | 01.00 | [Devil May Cry 4: Special Edition](https://hencheats.vercel.app/#CUSA01671-01.00) |
| 2026-07-16 | ADDED | CUSA03178 | 01.01 | [Resident Evil: Origins Collection](https://hencheats.vercel.app/#CUSA03178-01.01) |
| 2026-07-16 | ADDED | CUSA04607 | 01.02 | [Batman: Return to Arkham](https://hencheats.vercel.app/#CUSA04607-01.02) |
| 2026-07-16 | ADDED | CUSA08602 | 01.25 | [Call of Duty: WWII](https://hencheats.vercel.app/#CUSA08602-01.25) |
| 2026-07-16 | ADDED | CUSA08624 | 02.16 | [The Long Dark](https://hencheats.vercel.app/#CUSA08624-02.16) |
| 2026-07-16 | ADDED | CUSA10908 | 01.05 | [My Time at Portia](https://hencheats.vercel.app/#CUSA10908-01.05) |
| 2026-07-16 | ADDED | CUSA12641 | 01.09 | [Warriors Orochi 4](https://hencheats.vercel.app/#CUSA12641-01.09) |
| 2026-07-16 | ADDED | CUSA17776 | 01.14 | [Marvel's Spider-Man: Miles Morales](https://hencheats.vercel.app/#CUSA17776-01.14) |
| 2026-07-16 | ADDED | CUSA20133 | 01.12 | [Mortal Shell](https://hencheats.vercel.app/#CUSA20133-01.12) |
| 2026-07-16 | ADDED | CUSA25569 | 01.04 | [Evil West](https://hencheats.vercel.app/#CUSA25569-01.04) |
| 2026-07-16 | ADDED | CUSA26619 | 01.04 | [Grand Theft Auto: San Andreas - The Definitive Edition](https://hencheats.vercel.app/#CUSA26619-01.04) |
| 2026-07-16 | ADDED | CUSA27321 | 01.30 | [Jurassic World Evolution 2](https://hencheats.vercel.app/#CUSA27321-01.30) |
| 2026-07-16 | ADDED | CUSA29772 | 01.01 | [River City Girls Zero](https://hencheats.vercel.app/#CUSA29772-01.01) |
| 2026-07-16 | ADDED | CUSA32132 | 01.13 | [Like a Dragon: Infinite Wealth](https://hencheats.vercel.app/#CUSA32132-01.13) |
| 2026-07-16 | ADDED | CUSA32809 | 01.10 | [Sword Art Online: Last Recollection](https://hencheats.vercel.app/#CUSA32809-01.10) |
| 2026-07-16 | ADDED | CUSA33758 | 01.01 | [Soulcalibur: Broken Destiny](https://hencheats.vercel.app/#CUSA33758-01.01) |
| 2026-07-16 | ADDED | CUSA33877 | 01.00 | [Resident Evil Director's Cut](https://hencheats.vercel.app/#CUSA33877-01.00) |
| 2026-07-16 | ADDED | CUSA34388 | 02.04 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34388-02.04) |
| 2026-07-16 | ADDED | CUSA34388 | 03.00 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34388-03.00) |
| 2026-07-16 | ADDED | CUSA34390 | 02.04 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34390-02.04) |
| 2026-07-16 | ADDED | CUSA34698 | 01.03 | [Sand Land](https://hencheats.vercel.app/#CUSA34698-01.03) |
| 2026-07-16 | ADDED | CUSA34766 | 01.05 | [Granblue Fantasy: Relink](https://hencheats.vercel.app/#CUSA34766-01.05) |
| 2026-07-16 | ADDED | CUSA34896 | 01.01 | [Beyond Good & Evil 20th Anniversary Edition](https://hencheats.vercel.app/#CUSA34896-01.01) |
| 2026-07-16 | ADDED | CUSA36582 | 01.01 | [Prince of Persia: The Lost Crown](https://hencheats.vercel.app/#CUSA36582-01.01) |
| 2026-07-16 | ADDED | CUSA39420 | 01.02 | [Hollow Knight: Silksong](https://hencheats.vercel.app/#CUSA39420-01.02) |
| 2026-07-16 | ADDED | CUSA40247 | 01.04 | [Forgive Me Father](https://hencheats.vercel.app/#CUSA40247-01.04) |
| 2026-07-16 | ADDED | PPSA14033 | 01.000.000 | [Everspace 2 Stellar Edition](https://hencheats.vercel.app/#PPSA14033-01.000.000) |
| 2026-07-16 | ADDED | CUSA45404 | 01.01 | [Crazy Chicken Traps and Treasure 2](https://hencheats.vercel.app/#CUSA45404-01.01) |
| 2026-07-16 | ADDED | PPSA08448 | 01.000.000 | [Asterix & Obelix XXXL: The Ram From Hibernia](https://hencheats.vercel.app/#PPSA08448-01.000.000) |
| 2026-07-16 | ADDED | PPSA02985 | 02.001.000 | [Fishing: North Atlantic](https://hencheats.vercel.app/#PPSA02985-02.001.000) |
| 2026-07-16 | ADDED | CUSA34386 | 05.03 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34386-05.03) |
| 2026-07-16 | ADDED | CUSA34388 | 05.03 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34388-05.03) |
| 2026-07-16 | ADDED | CUSA34390 | 05.03 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34390-05.03) |
| 2026-07-16 | ADDED | CUSA34392 | 05.03 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34392-05.03) |
| 2026-07-16 | ADDED | CUSA34394 | 05.03 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34394-05.03) |
| 2026-07-16 | ADDED | CUSA00740 | 01.28 | [Terraria](https://hencheats.vercel.app/#CUSA00740-01.28) |
| 2026-07-16 | ADDED | CUSA01839 | 01.07 | [Ultra Street Fighter IV](https://hencheats.vercel.app/#CUSA01839-01.07) |
| 2026-07-16 | ADDED | CUSA03979 | 01.03 | [BioShock: The Collection](https://hencheats.vercel.app/#CUSA03979-01.03) |
| 2026-07-16 | ADDED | CUSA08603 | 01.25 | [Call of Duty: WWII](https://hencheats.vercel.app/#CUSA08603-01.25) |
| 2026-07-16 | ADDED | CUSA11147 | 01.00 | [Onimusha: Warlords](https://hencheats.vercel.app/#CUSA11147-01.00) |
| 2026-07-16 | ADDED | CUSA12289 | 01.06 | [Shenmue III](https://hencheats.vercel.app/#CUSA12289-01.06) |
| 2026-07-16 | ADDED | CUSA14332 | 01.00 | [Ashen](https://hencheats.vercel.app/#CUSA14332-01.00) |
| 2026-07-16 | ADDED | CUSA14925 | 02.21 | [Bus Simulator 21](https://hencheats.vercel.app/#CUSA14925-02.21) |
| 2026-07-16 | ADDED | CUSA18917 | 01.07 | [Neon Abyss](https://hencheats.vercel.app/#CUSA18917-01.07) |
| 2026-07-16 | ADDED | CUSA20605 | 01.04 | [Rebel Galaxy Outlaw](https://hencheats.vercel.app/#CUSA20605-01.04) |
| 2026-07-16 | ADDED | CUSA25272 | 01.00 | [The King of Fighters XV](https://hencheats.vercel.app/#CUSA25272-01.00) |
| 2026-07-16 | ADDED | CUSA25502 | 01.18 | [Hot Wheels Unleashed](https://hencheats.vercel.app/#CUSA25502-01.18) |
| 2026-07-16 | ADDED | CUSA25882 | 01.16 | [WWE 2K22](https://hencheats.vercel.app/#CUSA25882-01.16) |
| 2026-07-16 | ADDED | CUSA26377 | 01.02 | [NEO: The World Ends with You](https://hencheats.vercel.app/#CUSA26377-01.02) |
| 2026-07-16 | ADDED | CUSA28381 | 01.01 | [DreamWorks Dragons: Legends of The Nine Realms](https://hencheats.vercel.app/#CUSA28381-01.01) |
| 2026-07-16 | ADDED | CUSA29578 | 01.12 | [Stranger of Paradise: Final Fantasy Origin](https://hencheats.vercel.app/#CUSA29578-01.12) |
| 2026-07-16 | ADDED | CUSA29671 | 01.01 | [Airport Simulator: Day & Night](https://hencheats.vercel.app/#CUSA29671-01.01) |
| 2026-07-16 | ADDED | CUSA34392 | 05.05 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34392-05.05) |
| 2026-07-16 | ADDED | CUSA34394 | 05.05 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34394-05.05) |
| 2026-07-16 | ADDED | PPSA02629 | 02.000.000 | [Trek to Yomi](https://hencheats.vercel.app/#PPSA02629-02.000.000) |
| 2026-07-16 | ADDED | PPSA03952 | 01.000.000 | [Resident Evil 3](https://hencheats.vercel.app/#PPSA03952-01.000.000) |
| 2026-07-16 | ADDED | CUSA48215 | 01.01 | [Wrath: Aeon of Ruin](https://hencheats.vercel.app/#CUSA48215-01.01) |
| 2026-07-16 | UPDATE | CUSA01708 | 01.00 | [Devil May Cry 4: Special Edition](https://hencheats.vercel.app/#CUSA01708-01.00) |
| 2026-07-16 | UPDATE | CUSA14835 | 01.91 | [Dragon Ball Z: Kakarot](https://hencheats.vercel.app/#CUSA14835-01.91) |
| 2026-07-16 | UPDATE | CUSA27373 | 01.12 | [The Callisto Protocol](https://hencheats.vercel.app/#CUSA27373-01.12) |
| 2026-07-16 | UPDATE | CUSA33151 | 01.07 | [Assassin's Creed Mirage](https://hencheats.vercel.app/#CUSA33151-01.07) |
| 2026-07-16 | UPDATE | CUSA33151 | 01.11 | [Assassin's Creed Mirage](https://hencheats.vercel.app/#CUSA33151-01.11) |
| 2026-07-16 | UPDATE | CUSA33388 | 01.04 | [Resident Evil 4](https://hencheats.vercel.app/#CUSA33388-01.04) |
| 2026-07-16 | UPDATE | CUSA34029 | 01.08 | [Call of Duty: Modern Warfare II](https://hencheats.vercel.app/#CUSA34029-01.08) |
| 2026-07-16 | UPDATE | CUSA34384 | 05.01 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34384-05.01) |
| 2026-07-16 | UPDATE | CUSA14123 | 01.05 | [Resident Evil 3](https://hencheats.vercel.app/#CUSA14123-01.05) |
| 2026-07-16 | UPDATE | CUSA34386 | 05.01 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34386-05.01) |
| 2026-07-16 | UPDATE | CUSA34388 | 04.02 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34388-04.02) |
| 2026-07-16 | UPDATE | CUSA34388 | 05.01 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34388-05.01) |
| 2026-07-16 | UPDATE | CUSA34390 | 05.01 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34390-05.01) |
| 2026-07-16 | UPDATE | CUSA34392 | 05.01 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34392-05.01) |
| 2026-07-16 | UPDATE | CUSA34394 | 05.01 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34394-05.01) |
| 2026-07-16 | UPDATE | CUSA39420 | 01.04 | [Hollow Knight: Silksong](https://hencheats.vercel.app/#CUSA39420-01.04) |
| 2026-07-16 | UPDATE | CUSA42378 | 01.04 | [Contra: Operation Galuga](https://hencheats.vercel.app/#CUSA42378-01.04) |
| 2026-07-16 | UPDATE | CUSA34388 | 02.00 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34388-02.00) |
| 2026-07-16 | UPDATE | CUSA55613 | 01.10 | [Plants vs. ZombiesT: Replanted](https://hencheats.vercel.app/#CUSA55613-01.10) |
| 2026-07-16 | UPDATE | CUSA12584 | 01.33 | [Dying Light 2: Stay Human](https://hencheats.vercel.app/#CUSA12584-01.33) |
| 2026-07-16 | UPDATE | CUSA02376 | 01.52 | [Assassin's Creed Syndicate](https://hencheats.vercel.app/#CUSA02376-01.52) |
| 2026-07-16 | UPDATE | CUSA34384 | 05.03 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34384-05.03) |
| 2026-07-16 | UPDATE | CUSA00250 | 01.02 | [Thief](https://hencheats.vercel.app/#CUSA00250-01.02) |
| 2026-07-16 | UPDATE | CUSA00369 | 01.03 | [Lords of the Fallen](https://hencheats.vercel.app/#CUSA00369-01.03) |
| 2026-07-16 | UPDATE | CUSA00377 | 01.03 | [Lords of the Fallen](https://hencheats.vercel.app/#CUSA00377-01.03) |
| 2026-07-16 | UPDATE | CUSA01671 | 01.00 | [Devil May Cry 4: Special Edition](https://hencheats.vercel.app/#CUSA01671-01.00) |
| 2026-07-16 | UPDATE | CUSA11456 | 02.18 | [Ghost of Tsushima](https://hencheats.vercel.app/#CUSA11456-02.18) |
| 2026-07-16 | UPDATE | CUSA11597 | 01.00 | [SteamWorld Dig 2](https://hencheats.vercel.app/#CUSA11597-01.00) |
| 2026-07-16 | UPDATE | CUSA07104 | 01.01 | [Resident Evil: Code: Veronica X](https://hencheats.vercel.app/#CUSA07104-01.01) |
| 2026-07-16 | UPDATE | CUSA13275 | 01.23 | [DOOM Eternal](https://hencheats.vercel.app/#CUSA13275-01.23) |
| 2026-07-16 | UPDATE | CUSA24605 | 01.12 | [Two Point Campus](https://hencheats.vercel.app/#CUSA24605-01.12) |
| 2026-07-16 | UPDATE | CUSA32132 | 01.13 | [Like a Dragon: Infinite Wealth](https://hencheats.vercel.app/#CUSA32132-01.13) |
| 2026-07-16 | UPDATE | CUSA34384 | 05.05 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34384-05.05) |
| 2026-07-16 | UPDATE | CUSA34386 | 05.05 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34386-05.05) |
| 2026-07-16 | UPDATE | CUSA34388 | 05.05 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34388-05.05) |
| 2026-07-16 | UPDATE | CUSA34390 | 05.05 | [God of War: Ragnarok](https://hencheats.vercel.app/#CUSA34390-05.05) |
| 2026-07-16 | UPDATE | CUSA42391 | 01.11 | [High on Life](https://hencheats.vercel.app/#CUSA42391-01.11) |
| 2026-07-16 | UPDATE | CUSA15717 | 01.09 | [Far Cry 6](https://hencheats.vercel.app/#CUSA15717-01.09) |
| 2026-07-16 | UPDATE | PPSA14251 | 01.006.000 | [Mafia: The Old Country](https://hencheats.vercel.app/#PPSA14251-01.006.000) |
| 2026-07-16 | ADDED | PPSA07257 | 05.000.000 | [Gotham Knights](https://hencheats.vercel.app/#PPSA07257-05.000.000) |
| 2026-07-16 | ADDED | PPSA13579 | 01.007.000 | [Blasphemous 2](https://hencheats.vercel.app/#PPSA13579-01.007.000) |
| 2026-07-15 | ADDED | CUSA03051 | 01.01 | [Guns, Gore & Cannoli](https://hencheats.vercel.app/#CUSA03051-01.01) |
| 2026-07-15 | ADDED | CUSA29199 | 01.03 | [Tormented Souls](https://hencheats.vercel.app/#CUSA29199-01.03) |
| 2026-07-15 | ADDED | CUSA50981 | 01.03 | [Beyond the Ice Palace 2](https://hencheats.vercel.app/#CUSA50981-01.03) |
| 2026-07-15 | ADDED | CUSA52187 | 01.50 | [Gal Guardians: Servants of the Dark](https://hencheats.vercel.app/#CUSA52187-01.50) |
| 2026-07-15 | UPDATE | CUSA17672 | 01.01 | [Valfaris](https://hencheats.vercel.app/#CUSA17672-01.01) |
| 2026-07-15 | UPDATE | CUSA30991 | 01.10 | [Teenage Mutant Ninja Turtles: Shredder's Revenge](https://hencheats.vercel.app/#CUSA30991-01.10) |
| 2026-07-15 | UPDATE | CUSA45905 | 01.01 | [SHINOBI: Art of Vengeance](https://hencheats.vercel.app/#CUSA45905-01.01) |
| 2026-07-15 | UPDATE | CUSA46721 | 01.01 | [Shadow of The Ninja](https://hencheats.vercel.app/#CUSA46721-01.01) |
| 2026-07-15 | UPDATE | CUSA50463 | 01.03 | [RetroRealms](https://hencheats.vercel.app/#CUSA50463-01.03) |
| 2026-07-15 | UPDATE | CUSA53132 | 01.02 | [Ninja Gaiden: Ragebound](https://hencheats.vercel.app/#CUSA53132-01.02) |
| 2026-07-15 | ADDED | PPSA02530 | 01.200.000 | [Pragmata](https://hencheats.vercel.app/#PPSA02530-01.200.000) |
| 2026-07-15 | ADDED | PPSA30797 | 01.000.005 | [Kaku: Ancient Seal](https://hencheats.vercel.app/#PPSA30797-01.000.005) |
| 2026-07-15 | ADDED | PPSA30490 | 01.000.000 | [Asterix & Obelix - Mission Babylon](https://hencheats.vercel.app/#PPSA30490-01.000.000) |
| 2026-07-15 | ADDED | PPSA28311 | 01.002.000 | [Absolum](https://hencheats.vercel.app/#PPSA28311-01.002.000) |
| 2026-07-15 | ADDED | PPSA26311 | 01.004.001 | [Blades of Fire](https://hencheats.vercel.app/#PPSA26311-01.004.001) |
| 2026-07-15 | ADDED | PPSA25872 | 01.002.000 | [Terminator 2D: No Fate](https://hencheats.vercel.app/#PPSA25872-01.002.000) |
| 2026-07-15 | ADDED | PPSA25009 | 01.008.000 | [Blue Prince](https://hencheats.vercel.app/#PPSA25009-01.008.000) |
| 2026-07-15 | ADDED | PPSA24152 | 01.000.000 | [Potionomics: Masterwork Edition](https://hencheats.vercel.app/#PPSA24152-01.000.000) |
| 2026-07-15 | ADDED | PPSA23000 | 01.000.000 | [Double Dragon Revive](https://hencheats.vercel.app/#PPSA23000-01.000.000) |
| 2026-07-15 | ADDED | PPSA21297 | 01.000.000 | [Withering Rooms](https://hencheats.vercel.app/#PPSA21297-01.000.000) |
| 2026-07-15 | ADDED | PPSA20298 | 01.040.000 | [Shadow Labyrinth](https://hencheats.vercel.app/#PPSA20298-01.040.000) |
| 2026-07-15 | ADDED | PPSA19406 | 01.005.000 | [Earth Defense Force: World Brothers 2](https://hencheats.vercel.app/#PPSA19406-01.005.000) |
| 2026-07-15 | ADDED | PPSA17219 | 01.000.001 | [Disney Illusion Island](https://hencheats.vercel.app/#PPSA17219-01.000.001) |
| 2026-07-15 | ADDED | PPSA16716 | 01.000.000 | [The Smurfs 2: The Prisoner of the Green Stone](https://hencheats.vercel.app/#PPSA16716-01.000.000) |
| 2026-07-15 | ADDED | PPSA16019 | 01.000.000 | [Double Dragon Gaiden: Rise of the Dragons](https://hencheats.vercel.app/#PPSA16019-01.000.000) |
| 2026-07-15 | ADDED | PPSA15645 | 01.003.000 | [Castlevania Dominus Collection](https://hencheats.vercel.app/#PPSA15645-01.003.000) |
| 2026-07-15 | ADDED | PPSA14196 | 01.000.000 | [Sker Ritual](https://hencheats.vercel.app/#PPSA14196-01.000.000) |
| 2026-07-15 | ADDED | PPSA10053 | 01.005.000 | [Banishers: Ghosts of New Eden](https://hencheats.vercel.app/#PPSA10053-01.005.000) |
| 2026-07-15 | ADDED | PPSA09453 | 01.000.002 | [Infinity Strash: DRAGON QUEST The Adventure of Dai](https://hencheats.vercel.app/#PPSA09453-01.000.002) |
| 2026-07-15 | ADDED | PPSA09347 | 08.000.000 | [The Last Faith](https://hencheats.vercel.app/#PPSA09347-08.000.000) |
| 2026-07-15 | ADDED | PPSA09090 | 01.000.000 | [Lunar Lander: Beyond](https://hencheats.vercel.app/#PPSA09090-01.000.000) |
| 2026-07-15 | ADDED | PPSA08546 | 01.000.000 | [Flashback 2 Limited Edition](https://hencheats.vercel.app/#PPSA08546-01.000.000) |
| 2026-07-15 | ADDED | PPSA05344 | 04.001.000 | [Park Beyond](https://hencheats.vercel.app/#PPSA05344-04.001.000) |
| 2026-07-15 | ADDED | PPSA04243 | 01.000.000 | [Breathedge](https://hencheats.vercel.app/#PPSA04243-01.000.000) |
| 2026-07-15 | ADDED | CUSA04704 | 01.01 | [Resident Evil 4](https://hencheats.vercel.app/#CUSA04704-01.01) |
| 2026-07-15 | ADDED | CUSA32065 | 01.01 | [Super Cyborg](https://hencheats.vercel.app/#CUSA32065-01.01) |
| 2026-07-15 | UPDATE | CUSA10455 | 01.07 | [Borderlands: Game of the Year Edition](https://hencheats.vercel.app/#CUSA10455-01.07) |
| 2026-07-15 | UPDATE | CUSA48853 | 01.02 | [Elden Ring Nightreign](https://hencheats.vercel.app/#CUSA48853-01.02) |
| 2026-07-15 | UPDATE | CUSA50614 | 01.02 | [Elden Ring Nightreign](https://hencheats.vercel.app/#CUSA50614-01.02) |
| 2026-07-15 | UPDATE | CUSA50615 | 01.02 | [Elden Ring Nightreign](https://hencheats.vercel.app/#CUSA50615-01.02) |
| 2026-07-15 | UPDATE | CUSA50617 | 01.02 | [Elden Ring Nightreign](https://hencheats.vercel.app/#CUSA50617-01.02) |
| 2026-07-15 | UPDATE | CUSA05786 | 01.04 | [Kingdom Hearts: HD 1.5 + 2.5 ReMIX](https://hencheats.vercel.app/#CUSA05786-01.04) |
| 2026-07-15 | UPDATE | CUSA11454 | 01.12 | [Control](https://hencheats.vercel.app/#CUSA11454-01.12) |
| 2026-07-15 | UPDATE | CUSA11898 | 01.09 | [Divinity: Original Sin II: Definitive Edition](https://hencheats.vercel.app/#CUSA11898-01.09) |
| 2026-07-15 | UPDATE | CUSA34370 | 01.08 | [Aliens: Dark Descent](https://hencheats.vercel.app/#CUSA34370-01.08) |
| 2026-07-15 | UPDATE | PPSA10261 | 01.000.000 | [Lies of P](https://hencheats.vercel.app/#PPSA10261-01.000.000) |
| 2026-07-15 | UPDATE | PPSA03016 | 01.004.003 | [Marvel’s Spider-Man 2](https://hencheats.vercel.app/#PPSA03016-01.004.003) |
| 2026-07-12 | ADDED | PPSA20800 | 01.013.000 | [Metaphor: ReFantazio](https://hencheats.vercel.app/#PPSA20800-01.013.000) |
| 2026-07-11 | ADDED | PPSA24588 | 01.100.001 | [The Outer Worlds 2](https://hencheats.vercel.app/#PPSA24588-01.100.001) |
| 2026-07-11 | ADDED | PPSA34823 | 01.000.001 | [New Super Lucky's Tale](https://hencheats.vercel.app/#PPSA34823-01.000.001) |
| 2026-07-11 | ADDED | PPSA23226 | 01.000.021 | [Black Myth: Wukong](https://hencheats.vercel.app/#PPSA23226-01.000.021) |
| 2026-07-11 | UPDATE | PPSA26344 | 01.008.000 | [Ghost of Yotei](https://hencheats.vercel.app/#PPSA26344-01.008.000) |
| 2026-07-10 | UPDATE | PPSA02262 | 01.054.000 | [Dying Light 2: Stay Human](https://hencheats.vercel.app/#PPSA02262-01.054.000) |
| 2026-07-10 | UPDATE | PPSA01490 | 01.070.000 | [Assassin's Creed Valhalla](https://hencheats.vercel.app/#PPSA01490-01.070.000) |
| 2026-07-09 | ADDED | PPSA01500 | 01.190.000 | [Watch Dogs: Legion](https://hencheats.vercel.app/#PPSA01500-01.190.000) |
| 2026-07-09 | UPDATE | PPSA26873 | 01.000.002 | [Monster Hunter Stories 3: Twisted Reflection](https://hencheats.vercel.app/#PPSA26873-01.000.002) |
| 2026-07-09 | ADDED | PPSA21567 | 01.018.000 | [Astro Bot](https://hencheats.vercel.app/#PPSA21567-01.018.000) |
| 2026-07-08 | ADDED | PPSA32785 | 01.040.020 | [Nioh 3](https://hencheats.vercel.app/#PPSA32785-01.040.020) |
| 2026-07-08 | ADDED | PPSA22327 | 01.685.672 | [Forza Horizon 5](https://hencheats.vercel.app/#PPSA22327-01.685.672) |
| 2026-07-06 | ADDED | PPSA21564 | 01.018.000 | [Astro Bot](https://hencheats.vercel.app/#PPSA21564-01.018.000) |
| 2026-07-06 | ADDED | PPSA23226 | 01.000.021 | [Black Myth: Wukong](https://hencheats.vercel.app/#PPSA23226-01.000.021) |
| 2026-07-06 | ADDED | PPSA06215 | 01.007.000 | [Outward: Definitive Edition](https://hencheats.vercel.app/#PPSA06215-01.007.000) |
| 2026-07-06 | ADDED | PPSA08804 | 01.012.000 | [Sonic Racing: CrossWorlds](https://hencheats.vercel.app/#PPSA08804-01.012.000) |
| 2026-07-06 | ADDED | PPSA26873 | 01.000.002 | [Monster Hunter Stories 3: Twisted Reflection](https://hencheats.vercel.app/#PPSA26873-01.000.002) |
| 2026-07-06 | UPDATE | PPSA02262 | 01.054.000 | [Dying Light 2: Stay Human](https://hencheats.vercel.app/#PPSA02262-01.054.000) |
| 2026-07-06 | UPDATE | PPSA03845 | 01.000.004 | [Dead Space](https://hencheats.vercel.app/#PPSA03845-01.000.004) |
| 2026-07-06 | UPDATE | PPSA01556 | 01.210.000 | [Resident Evil Village](https://hencheats.vercel.app/#PPSA01556-01.210.000) |
| 2026-07-06 | UPDATE | PPSA03099 | 01.000.001 | [Dead Island 2](https://hencheats.vercel.app/#PPSA03099-01.000.001) |
| 2026-07-06 | UPDATE | PPSA08710 | 01.005.000 | [Silent Hill 2](https://hencheats.vercel.app/#PPSA08710-01.005.000) |
| 2026-07-06 | UPDATE | PPSA26786 | 01.009.000 | [Indiana Jones and The Great Circle](https://hencheats.vercel.app/#PPSA26786-01.009.000) |
| 2026-07-06 | ADDED | PPSA04539 | 01.009.000 | [Rise of the Ronin](https://hencheats.vercel.app/#PPSA04539-01.009.000) |
| 2026-07-06 | ADDED | PPSA04540 | 01.009.000 | [Rise of the Ronin](https://hencheats.vercel.app/#PPSA04540-01.009.000) |
| 2026-07-05 | ADDED | PPSA24884 | 01.000.002 | [Starfield](https://hencheats.vercel.app/#PPSA24884-01.000.002) |
| 2026-07-04 | UPDATE | PPSA02015 | 01.013.000 | [Death Stranding 2: On the Beach](https://hencheats.vercel.app/#PPSA02015-01.013.000) |
| 2026-07-04 | ADDED | PPSA01442 | 01.002.000 | [Devil May Cry 5: Special Edition](https://hencheats.vercel.app/#PPSA01442-01.002.000) |
| 2026-07-04 | ADDED | PPSA01442 | 01.003.000 | [Devil May Cry 5: Special Edition](https://hencheats.vercel.app/#PPSA01442-01.003.000) |
| 2026-07-04 | ADDED | PPSA01443 | 01.002.000 | [Devil May Cry 5: Special Edition](https://hencheats.vercel.app/#PPSA01443-01.002.000) |
| 2026-07-04 | ADDED | PPSA01443 | 01.003.000 | [Devil May Cry 5: Special Edition](https://hencheats.vercel.app/#PPSA01443-01.003.000) |
| 2026-07-04 | ADDED | PPSA02262 | 01.054.000 | [Dying Light 2: Stay Human](https://hencheats.vercel.app/#PPSA02262-01.054.000) |
| 2026-07-03 | ADDED | PPSA01473 | 01.005.003 | [Ratchet & Clank: Rift Apart](https://hencheats.vercel.app/#PPSA01473-01.005.003) |
| 2026-07-03 | ADDED | PPSA01474 | 01.005.003 | [Ratchet & Clank: Rift Apart](https://hencheats.vercel.app/#PPSA01474-01.005.003) |
| 2026-07-02 | ADDED | PPSA01670 | 01.405.000 | [Deathloop](https://hencheats.vercel.app/#PPSA01670-01.405.000) |
| 2026-07-02 | ADDED | PPSA01490 | 01.070.000 | [Assassin's Creed Valhalla](https://hencheats.vercel.app/#PPSA01490-01.070.000) |
| 2026-07-02 | ADDED | PPSA01870 | 01.000.013 | [Far Cry 6](https://hencheats.vercel.app/#PPSA01870-01.000.013) |
| 2026-07-02 | ADDED | PPSA04404 | 01.000.004 | [RESIDENT EVIL 7 biohazard](https://hencheats.vercel.app/#PPSA04404-01.000.004) |
| 2026-07-02 | ADDED | PPSA07809 | 01.004.000 | [Crisis Core: Final Fantasy VII: Reunion](https://hencheats.vercel.app/#PPSA07809-01.004.000) |
| 2026-07-02 | ADDED | PPSA07810 | 01.004.000 | [Crisis Core: Final Fantasy VII: Reunion](https://hencheats.vercel.app/#PPSA07810-01.004.000) |
| 2026-07-02 | ADDED | PPSA07862 | 01.030.020 | [Monster Hunter Wilds](https://hencheats.vercel.app/#PPSA07862-01.030.020) |
| 2026-07-02 | UPDATE | PPSA02572 | 01.200.007 | [Alan Wake 2](https://hencheats.vercel.app/#PPSA02572-01.200.007) |
| 2026-07-02 | UPDATE | PPSA30528 | 01.002.000 | [Red Dead Redemption](https://hencheats.vercel.app/#PPSA30528-01.002.000) |
| 2026-07-01 | ADDED | PPSA02985 | 02.001.000 | [Fishing: North Atlantic](https://hencheats.vercel.app/#PPSA02985-02.001.000) |
| 2026-07-01 | UPDATE | PPSA03984 | 01.020.000 | [Forspoken](https://hencheats.vercel.app/#PPSA03984-01.020.000) |
| 2026-07-01 | UPDATE | PPSA24701 | 01.000.011 | [Digimon Story Time Stranger](https://hencheats.vercel.app/#PPSA24701-01.000.011) |
| 2026-07-01 | UPDATE | PPSA26786 | 01.009.000 | [Indiana Jones and The Great Circle](https://hencheats.vercel.app/#PPSA26786-01.009.000) |
| 2026-07-01 | ADDED | PPSA02572 | 01.200.007 | [Alan Wake 2](https://hencheats.vercel.app/#PPSA02572-01.200.007) |
| 2026-07-01 | ADDED | CUSA50617 | 01.21 | [Elden Ring Nightreign](https://hencheats.vercel.app/#CUSA50617-01.21) |
| 2026-07-01 | ADDED | PPSA26097 | 02.000.000 | [Yooka-Replaylee](https://hencheats.vercel.app/#PPSA26097-02.000.000) |
| 2026-07-01 | ADDED | PPSA24701 | 01.000.011 | [Digimon Story Time Stranger](https://hencheats.vercel.app/#PPSA24701-01.000.011) |
| 2026-07-01 | ADDED | PPSA23885 | 01.000.000 | [Little Big Adventure – Twinsen’s Quest](https://hencheats.vercel.app/#PPSA23885-01.000.000) |
| 2026-07-01 | ADDED | PPSA20548 | 01.003.001 | [Eriksholm: The Stolen Dream](https://hencheats.vercel.app/#PPSA20548-01.003.001) |
| 2026-07-01 | ADDED | PPSA19268 | 01.000.000 | [Juicy Realm](https://hencheats.vercel.app/#PPSA19268-01.000.000) |
| 2026-07-01 | ADDED | PPSA17525 | 01.008.001 | [Gears of War: Reloaded](https://hencheats.vercel.app/#PPSA17525-01.008.001) |
| 2026-07-01 | ADDED | PPSA10664 | 01.003.004 | [Final Fantasy XVI](https://hencheats.vercel.app/#PPSA10664-01.003.004) |
| 2026-07-01 | ADDED | PPSA10050 | 01.000.000 | [Saga Of Sins](https://hencheats.vercel.app/#PPSA10050-01.000.000) |
| 2026-07-01 | ADDED | PPSA08427 | 02.006.000 | [Killing Floor 3](https://hencheats.vercel.app/#PPSA08427-02.006.000) |
| 2026-07-01 | ADDED | PPSA06774 | 01.009.000 | [Armored Core VI: Fires of Rubicon](https://hencheats.vercel.app/#PPSA06774-01.009.000) |
| 2026-07-01 | ADDED | PPSA06399 | 01.000.002 | [Pac-Man World Re-Pac](https://hencheats.vercel.app/#PPSA06399-01.000.002) |
| 2026-07-01 | ADDED | PPSA05721 | 01.000.005 | [Wytchwood](https://hencheats.vercel.app/#PPSA05721-01.000.005) |
| 2026-07-01 | ADDED | PPSA26358 | 01.000.000 | [Lost Soul Aside™](https://hencheats.vercel.app/#PPSA26358-01.000.000) |
| 2026-07-01 | ADDED | PPSA05366 | 01.005.000 | [A Plague Tale: Requiem](https://hencheats.vercel.app/#PPSA05366-01.005.000) |
| 2026-07-01 | ADDED | PPSA04181 | 01.000.002 | [Hoa](https://hencheats.vercel.app/#PPSA04181-01.000.002) |
| 2026-07-01 | ADDED | PPSA03984 | 01.020.000 | [Forspoken](https://hencheats.vercel.app/#PPSA03984-01.020.000) |
| 2026-07-01 | ADDED | PPSA03831 | 01.041.000 | [Sonic Frontiers](https://hencheats.vercel.app/#PPSA03831-01.041.000) |
| 2026-07-01 | ADDED | PPSA03157 | 01.004.000 | [Exodemon](https://hencheats.vercel.app/#PPSA03157-01.004.000) |
| 2026-07-01 | ADDED | PPSA02801 | 01.000.003 | [New Joe & Mac: Caveman Ninja](https://hencheats.vercel.app/#PPSA02801-01.000.003) |
| 2026-07-01 | ADDED | PPSA02395 | 01.001.000 | [Metro Exodus](https://hencheats.vercel.app/#PPSA02395-01.001.000) |
| 2026-07-01 | ADDED | PPSA02387 | 01.000.000 | [A Plague Tale: Innocence](https://hencheats.vercel.app/#PPSA02387-01.000.000) |
| 2026-07-01 | ADDED | PPSA01981 | 01.011.000 | [Doom Eternal](https://hencheats.vercel.app/#PPSA01981-01.011.000) |
| 2026-07-01 | ADDED | PPSA01886 | 01.000.003 | [Evergate](https://hencheats.vercel.app/#PPSA01886-01.000.003) |
| 2026-07-01 | ADDED | PPSA01685 | 01.031.000 | [Sniper Elite 5](https://hencheats.vercel.app/#PPSA01685-01.031.000) |
| 2026-07-01 | ADDED | PPSA01507 | 04.004.000 | [Immortals Fenyx Rising](https://hencheats.vercel.app/#PPSA01507-04.004.000) |
| 2026-07-01 | ADDED | PPSA01474 | 01.005.003 | [Ratchet & Clank: Rift Apart](https://hencheats.vercel.app/#PPSA01474-01.005.003) |
| 2026-07-01 | ADDED | PPSA27676 | 01.007.000 | [Painkiller](https://hencheats.vercel.app/#PPSA27676-01.007.000) |

</details>

<details>
<summary><b>June 2026</b></summary>

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-06-28 | ADDED | PPSA13427 | 01.008.001 | [Horizon Zero Dawn Remastered](https://hencheats.vercel.app/#PPSA13427-01.008.001) |
| 2026-06-28 | ADDED | PPSA13428 | 01.008.001 | [Horizon Zero Dawn Remastered](https://hencheats.vercel.app/#PPSA13428-01.008.001) |
| 2026-06-27 | UPDATE | PPSA20396 | 01.019.076 | [Assassin's Creed Shadows](https://hencheats.vercel.app/#PPSA20396-01.019.076) |
| 2026-06-27 | UPDATE | PPSA20397 | 01.019.076 | [Assassin's Creed Shadows](https://hencheats.vercel.app/#PPSA20397-01.019.076) |
| 2026-06-27 | ADDED | CUSA26613 | 01.04 | [Grand Theft Auto III - The Definitive Edition](https://hencheats.vercel.app/#CUSA26613-01.04) |
| 2026-06-25 | ADDED | PPSA20397 | 01.019.076 | [Assassin’s Creed Shadows](https://hencheats.vercel.app/#PPSA20397-01.019.076) |
| 2026-06-23 | ADDED | CUSA50981 | 01.03 | [Beyond the Ice Palace 2](https://hencheats.vercel.app/#CUSA50981-01.03) |
| 2026-06-23 | ADDED | CUSA52187 | 01.50 | [Gal Guardians: Servants of the Dark](https://hencheats.vercel.app/#CUSA52187-01.50) |
| 2026-06-23 | UPDATE | CUSA02010 | 01.47 | [Dying Light](https://hencheats.vercel.app/#CUSA02010-01.47) |
| 2026-06-21 | UPDATE | PPSA28336 | 01.009.000 | [S.T.A.L.K.E.R. 2: Heart of Chornobyl](https://hencheats.vercel.app/#PPSA28336-01.009.000) |
| 2026-06-20 | ADDED | PPSA01471 | 01.008.001 | [Marvel's Spider-Man Remastered](https://hencheats.vercel.app/#PPSA01471-01.008.001) |
| 2026-06-20 | UPDATE | PPSA01467 | 01.008.001 | [Marvel's Spider-Man Remastered](https://hencheats.vercel.app/#PPSA01467-01.008.001) |
| 2026-06-20 | UPDATE | PPSA03016 | 01.004.003 | [Marvel’s Spider-Man 2](https://hencheats.vercel.app/#PPSA03016-01.004.003) |
| 2026-06-19 | ADDED | PPSA02015 | 01.013.000 | [DEATH STRANDING 2: ON THE BEACH](https://hencheats.vercel.app/#PPSA02015-01.013.000) |
| 2026-06-18 | ADDED | PPSA25258 | 01.004.000 | [NINJA GAIDEN 4](https://hencheats.vercel.app/#PPSA25258-01.004.000) |
| 2026-06-16 | ADDED | PPSA07230 | 01.012.000 | [Assassin's Creed Mirage](https://hencheats.vercel.app/#PPSA07230-01.012.000) |
| 2026-06-16 | ADDED | PPSA20396 | 01.019.076 | [Assassin’s Creed Shadows](https://hencheats.vercel.app/#PPSA20396-01.019.076) |
| 2026-06-15 | ADDED | PPSA01467 | 01.008.001 | [Marvel's Spider-Man Remastered](https://hencheats.vercel.app/#PPSA01467-01.008.001) |
| 2026-06-14 | ADDED | PPSA17905 | 01.030.000 | [Horizon Forbidden West](https://hencheats.vercel.app/#PPSA17905-01.030.000) |
| 2026-06-14 | UPDATE | CUSA01244 | 01.01 | [Final Fantasy X - X-2: HD Remaster](https://hencheats.vercel.app/#CUSA01244-01.01) |
| 2026-06-14 | UPDATE | CUSA09407 | 01.00 | [Devil May Cry: HD Collection](https://hencheats.vercel.app/#CUSA09407-01.00) |
| 2026-06-14 | UPDATE | CUSA02882 | 01.00 | [Resident Evil: Origins Collection](https://hencheats.vercel.app/#CUSA02882-01.00) |
| 2026-06-14 | ADDED | XXXX00000 | 00.00 | **Added new cheat-files for 765 PS4 games** |
| 2026-06-11 | ADDED | PPSA23806 | 01.002.000 | [Darksiders II: Deathinitive Edition](https://hencheats.vercel.app/#PPSA23806-01.002.000) |
| 2026-06-11 | UPDATE | CUSA06339 | 01.01 | [Twin Robots](https://hencheats.vercel.app/#CUSA06339-01.01) |
| 2026-06-11 | UPDATE | CUSA08495 | 01.03 | [Dark Souls: Remastered](https://hencheats.vercel.app/#CUSA08495-01.03) |
| 2026-06-11 | UPDATE | CUSA08343 | 01.03 | [Senran Kagura: Peach Beach Splash](https://hencheats.vercel.app/#CUSA08343-01.03) |
| 2026-06-11 | UPDATE | CUSA08306 | 01.00 | [One Piece: Unlimited World Red: Deluxe Edition](https://hencheats.vercel.app/#CUSA08306-01.00) |
| 2026-06-11 | UPDATE | CUSA07615 | 01.09 | [Yakuza Kiwami](https://hencheats.vercel.app/#CUSA07615-01.09) |
| 2026-06-11 | UPDATE | CUSA07439 | 01.03 | [Dark Souls III: The Fire Fades Edition](https://hencheats.vercel.app/#CUSA07439-01.03) |
| 2026-06-11 | UPDATE | CUSA06014 | 01.12 | [Tekken 7](https://hencheats.vercel.app/#CUSA06014-01.12) |
| 2026-06-11 | UPDATE | CUSA08495 | 05.05 | [Dark Souls: Remastered](https://hencheats.vercel.app/#CUSA08495-05.05) |
| 2026-06-11 | UPDATE | CUSA06014 | 01.00 | [Tekken 7](https://hencheats.vercel.app/#CUSA06014-01.00) |
| 2026-06-11 | UPDATE | CUSA05574 | 01.50 | [The Witcher 3: Wild Hunt](https://hencheats.vercel.app/#CUSA05574-01.50) |
| 2026-06-11 | UPDATE | CUSA05573 | 01.50 | [The Witcher 3: Wild Hunt](https://hencheats.vercel.app/#CUSA05573-01.50) |
| 2026-06-11 | UPDATE | CUSA05486 | 01.09 | [The Elder Scrolls V: Skyrim Special Edition](https://hencheats.vercel.app/#CUSA05486-01.09) |
| 2026-06-11 | UPDATE | CUSA05486 | 01.00 | [The Elder Scrolls V: Skyrim Special Edition](https://hencheats.vercel.app/#CUSA05486-01.00) |
| 2026-06-11 | UPDATE | CUSA05350 | 01.50 | [Dragon Ball: Xenoverse 2](https://hencheats.vercel.app/#CUSA05350-01.50) |
| 2026-06-11 | UPDATE | CUSA05133 | 01.05 | [Yakuza 0](https://hencheats.vercel.app/#CUSA05133-01.05) |
| 2026-06-11 | UPDATE | CUSA05716 | 01.06 | [Rise of the Tomb Raider: 20 Year Celebration](https://hencheats.vercel.app/#CUSA05716-01.06) |
| 2026-06-11 | UPDATE | CUSA05032 | 01.07 | [Vikings: Wolves of Midgard](https://hencheats.vercel.app/#CUSA05032-01.07) |
| 2026-06-11 | UPDATE | CUSA08519 | 01.29 | [Red Dead Redemption II](https://hencheats.vercel.app/#CUSA08519-01.29) |
| 2026-06-11 | UPDATE | CUSA09171 | 01.04 | [Resident Evil 2](https://hencheats.vercel.app/#CUSA09171-01.04) |
| 2026-06-11 | UPDATE | CUSA42503 | 01.22 | [Atomfall](https://hencheats.vercel.app/#CUSA42503-01.22) |
| 2026-06-11 | UPDATE | CUSA37321 | 01.24 | [Atomic Heart](https://hencheats.vercel.app/#CUSA37321-01.24) |
| 2026-06-11 | UPDATE | CUSA33173 | 01.02 | [River City Girls 2](https://hencheats.vercel.app/#CUSA33173-01.02) |
| 2026-06-11 | UPDATE | CUSA28409 | 01.04 | [Vagante](https://hencheats.vercel.app/#CUSA28409-01.04) |
| 2026-06-11 | UPDATE | CUSA27373 | 01.12 | [The Callisto Protocol](https://hencheats.vercel.app/#CUSA27373-01.12) |
| 2026-06-11 | UPDATE | CUSA26546 | 01.03 | [Green Hell](https://hencheats.vercel.app/#CUSA26546-01.03) |
| 2026-06-11 | UPDATE | CUSA08779 | 01.02 | [Dishonored: Death of the Outsider](https://hencheats.vercel.app/#CUSA08779-01.02) |
| 2026-06-11 | UPDATE | CUSA16473 | 01.43 | [Astroneer](https://hencheats.vercel.app/#CUSA16473-01.43) |
| 2026-06-11 | UPDATE | CUSA15495 | 01.07 | [Surviving the Aftermath](https://hencheats.vercel.app/#CUSA15495-01.07) |
| 2026-06-11 | UPDATE | CUSA15280 | 01.22 | [Call of Duty: Modern Warfare](https://hencheats.vercel.app/#CUSA15280-01.22) |
| 2026-06-11 | UPDATE | CUSA14204 | 17.00 | [UFC 4](https://hencheats.vercel.app/#CUSA14204-17.00) |
| 2026-06-11 | UPDATE | CUSA14123 | 01.05 | [Resident Evil 3](https://hencheats.vercel.app/#CUSA14123-01.05) |
| 2026-06-11 | UPDATE | CUSA12555 | 01.62 | [Dying Light 2: Stay Human](https://hencheats.vercel.app/#CUSA12555-01.62) |
| 2026-06-11 | UPDATE | CUSA09243 | 01.00 | [Ni no Kuni II: Revenant Kingdom](https://hencheats.vercel.app/#CUSA09243-01.00) |
| 2026-06-11 | UPDATE | CUSA15690 | 01.02 | [Frostpunk](https://hencheats.vercel.app/#CUSA15690-01.02) |
| 2026-06-11 | UPDATE | CUSA43665 | 01.01 | [Turok 3: Shadow of Oblivion Remastered](https://hencheats.vercel.app/#CUSA43665-01.01) |
| 2026-06-11 | UPDATE | CUSA04885 | 01.01 | [Resident Evil 4](https://hencheats.vercel.app/#CUSA04885-01.01) |
| 2026-06-11 | UPDATE | CUSA03603 | 01.05 | [Dishonored 2](https://hencheats.vercel.app/#CUSA03603-01.05) |
| 2026-06-11 | UPDATE | CUSA12047 | 01.06 | [Sekiro: Shadows Die Twice](https://hencheats.vercel.app/#CUSA12047-01.06) |
| 2026-06-11 | UPDATE | CUSA05531 | 01.05 | [Final Fantasy XII: The Zodiac Age](https://hencheats.vercel.app/#CUSA05531-01.05) |
| 2026-06-11 | UPDATE | CUSA01515 | 01.04 | [Abyss Odyssey: Extended Dream Edition](https://hencheats.vercel.app/#CUSA01515-01.04) |
| 2026-06-11 | UPDATE | CUSA41300 | 01.02 | [Metal Gear Solid: Master Collection Vol. 1](https://hencheats.vercel.app/#CUSA41300-01.02) |
| 2026-06-11 | UPDATE | CUSA36986 | 01.11 | [Wo Long: Fallen Dynasty](https://hencheats.vercel.app/#CUSA36986-01.11) |
| 2026-06-11 | UPDATE | CUSA36846 | 01.11 | [Wo Long: Fallen Dynasty](https://hencheats.vercel.app/#CUSA36846-01.11) |
| 2026-06-11 | UPDATE | CUSA13285 | 01.00 | [Hollow Knight](https://hencheats.vercel.app/#CUSA13285-01.00) |
| 2026-06-11 | UPDATE | CUSA36818 | 01.11 | [Wo Long: Fallen Dynasty](https://hencheats.vercel.app/#CUSA36818-01.11) |
| 2026-06-11 | UPDATE | CUSA28863 | 01.13 | [Elden Ring](https://hencheats.vercel.app/#CUSA28863-01.13) |
| 2026-06-11 | UPDATE | CUSA27973 | 01.03 | [Hades](https://hencheats.vercel.app/#CUSA27973-01.03) |
| 2026-06-11 | UPDATE | CUSA18723 | 01.13 | [Elden Ring](https://hencheats.vercel.app/#CUSA18723-01.13) |
| 2026-06-11 | UPDATE | CUSA14835 | 01.91 | [Dragon Ball Z: Kakarot](https://hencheats.vercel.app/#CUSA14835-01.91) |
| 2026-06-11 | UPDATE | CUSA12403 | 01.01 | [Fall of Light: Darkest Edition](https://hencheats.vercel.app/#CUSA12403-01.01) |
| 2026-06-11 | UPDATE | CUSA08624 | 02.16 | [The Long Dark](https://hencheats.vercel.app/#CUSA08624-02.16) |
| 2026-06-11 | UPDATE | CUSA31340 | 01.06 | [Prodeus](https://hencheats.vercel.app/#CUSA31340-01.06) |
| 2026-06-11 | UPDATE | CUSA03651 | 01.01 | [One Piece: Burning Blood](https://hencheats.vercel.app/#CUSA03651-01.01) |
| 2026-06-11 | UPDATE | CUSA29850 | 01.04 | [DEADCRAFT](https://hencheats.vercel.app/#CUSA29850-01.04) |
| 2026-06-11 | UPDATE | CUSA00303 | 01.01 | [Bound by Flame](https://hencheats.vercel.app/#CUSA00303-01.01) |
| 2026-06-11 | UPDATE | CUSA03388 | 01.15 | [Dark Souls III](https://hencheats.vercel.app/#CUSA03388-01.15) |
| 2026-06-11 | UPDATE | CUSA03388 | 01.00 | [Dark Souls III](https://hencheats.vercel.app/#CUSA03388-01.00) |
| 2026-06-11 | UPDATE | CUSA03173 | 01.09 | [Bloodborne: Game of the Year Edition](https://hencheats.vercel.app/#CUSA03173-01.09) |
| 2026-06-11 | UPDATE | CUSA02491 | 01.10 | [Mass Effect: Andromeda](https://hencheats.vercel.app/#CUSA02491-01.10) |
| 2026-06-11 | UPDATE | CUSA02231 | 01.01 | [Dishonored: Definitive Edition](https://hencheats.vercel.app/#CUSA02231-01.01) |
| 2026-06-11 | UPDATE | CUSA02152 | 01.03 | [Middle-Earth: Shadow of Mordor: Game of the Year Edition](https://hencheats.vercel.app/#CUSA02152-01.03) |
| 2026-06-11 | UPDATE | CUSA31580 | 01.11 | [Sea of Stars](https://hencheats.vercel.app/#CUSA31580-01.11) |
| 2026-06-11 | UPDATE | CUSA01778 | 01.02 | [Dead or Alive 5: Last Round](https://hencheats.vercel.app/#CUSA01778-01.02) |
| 2026-06-11 | UPDATE | CUSA01200 | 01.02 | [Street Fighter V](https://hencheats.vercel.app/#CUSA01200-01.02) |
| 2026-06-11 | UPDATE | CUSA01082 | 01.06 | [The Evil Within](https://hencheats.vercel.app/#CUSA01082-01.06) |
| 2026-06-11 | UPDATE | CUSA01067 | 01.00 | [Resident Evil HD Remaster](https://hencheats.vercel.app/#CUSA01067-01.00) |
| 2026-06-11 | UPDATE | CUSA01004 | 01.01 | [Sleeping Dogs: Definitive Edition](https://hencheats.vercel.app/#CUSA01004-01.01) |
| 2026-06-11 | UPDATE | CUSA00633 | 01.09 | [Battlefield Hardline](https://hencheats.vercel.app/#CUSA00633-01.09) |
| 2026-06-11 | UPDATE | CUSA00303 | 01.02 | [Bound by Flame](https://hencheats.vercel.app/#CUSA00303-01.02) |
| 2026-06-11 | UPDATE | CUSA01742 | 01.00 | [One Piece: Pirate Warriors 3](https://hencheats.vercel.app/#CUSA01742-01.00) |
| 2026-06-11 | UPDATE | CUSA47364 | 01.01 | [The Karate Kid: Street Rumble](https://hencheats.vercel.app/#CUSA47364-01.01) |
| 2026-06-10 | ADDED | PPSA03016 | 01.004.003 | [Marvel’s Spider-Man 2](https://hencheats.vercel.app/#PPSA03016-01.004.003) |
| 2026-06-10 | ADDED | PPSA13195 | 01.014.001 | [Stellar Blade](https://hencheats.vercel.app/#PPSA13195-01.014.001) |
| 2026-06-10 | ADDED | PPSA15186 | 01.000.003 | [Vampire: The Masquerade® - Bloodlines™ 2](https://hencheats.vercel.app/#PPSA15186-01.000.003) |
| 2026-06-07 | UPDATE | PPSA25286 | 01.000.151 | [Crimson Desert](https://hencheats.vercel.app/#PPSA25286-01.000.151) |
| 2026-06-04 | UPDATE | PPSA02530 | 01.200.000 | [Pragmata](https://hencheats.vercel.app/#PPSA02530-01.200.000) |
| 2026-06-04 | UPDATE | PPSA07631 | 01.000.000 | [SAROS](https://hencheats.vercel.app/#PPSA07631-01.000.000) |
| 2026-06-03 | UPDATE | PPSA02530 | 01.200.000 | [Pragmata](https://hencheats.vercel.app/#PPSA02530-01.200.000) |
| 2026-06-03 | UPDATE | PPSA28336 | 01.009.000 | [S.T.A.L.K.E.R. 2: Heart of Chornobyl](https://hencheats.vercel.app/#PPSA28336-01.009.000) |
| 2026-06-01 | ADDED | PPSA28180 | 01.036.178 | [Days Gone: Remastered](https://hencheats.vercel.app/#PPSA28180-01.036.178) |

</details>

<details>
<summary><b>May 2026</b></summary>

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-05-31 | ADDED | PPSA28336 | 01.009.000 | [S.T.A.L.K.E.R. 2: Heart of Chornobyl](https://hencheats.vercel.app/#PPSA28336-01.009.000) |
| 2026-05-30 | ADDED | PPSA08236 | 01.006.004 | [Immortals of Aveum](https://hencheats.vercel.app/#PPSA08236-01.006.004) |
| 2026-05-27 | ADDED | PPSA25286 | 01.000.151 | [Crimson Desert](https://hencheats.vercel.app/#PPSA25286-01.000.151) |
| 2026-05-26 | ADDED | CUSA00265 | 02.35 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00265-02.35) |
| 2026-05-26 | ADDED | CUSA00283 | 01.95 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00283-01.95) |
| 2026-05-26 | ADDED | CUSA00283 | 02.06 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00283-02.06) |
| 2026-05-26 | ADDED | CUSA00283 | 02.35 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00283-02.35) |
| 2026-05-26 | ADDED | CUSA00283 | 02.64 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00283-02.64) |
| 2026-05-26 | ADDED | CUSA00744 | 02.06 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00744-02.06) |
| 2026-05-26 | ADDED | CUSA00744 | 02.64 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00744-02.64) |
| 2026-05-26 | ADDED | CUSA02387 | 01.27 | [Battlefield 1](https://hencheats.vercel.app/#CUSA02387-01.27) |
| 2026-05-26 | ADDED | CUSA18723 | 01.15 | [Elden Ring](https://hencheats.vercel.app/#CUSA18723-01.15) |
| 2026-05-26 | ADDED | CUSA23501 | 01.07 | [Grand Theft Auto III – The Definitive Edition](https://hencheats.vercel.app/#CUSA23501-01.07) |
| 2026-05-26 | UPDATE | CUSA00744 | 01.95 | [Minecraft: PlayStation 4 Edition](https://hencheats.vercel.app/#CUSA00744-01.95) |
| 2026-05-26 | UPDATE | CUSA00190 | 01.81 | [Killzone: Shadow Fall](https://hencheats.vercel.app/#CUSA00190-01.81) |
| 2026-05-26 | UPDATE | CUSA11260 | 01.13 | [Death Stranding](https://hencheats.vercel.app/#CUSA11260-01.13) |
| 2026-05-26 | UPDATE | CUSA28863 | 01.17 | [Elden Ring](https://hencheats.vercel.app/#CUSA28863-01.17) |
| 2026-05-26 | UPDATE | CUSA33173 | 01.02 | [River City Girls 2](https://hencheats.vercel.app/#CUSA33173-01.02) |
| 2026-05-26 | UPDATE | CUSA34766 | 01.05 | [Granblue Fantasy: Relink](https://hencheats.vercel.app/#CUSA34766-01.05) |
| 2026-05-26 | UPDATE | CUSA00049 | 01.24 | [Battlefield 4](https://hencheats.vercel.app/#CUSA00049-01.24) |
| 2026-05-26 | UPDATE | CUSA02429 | 01.00 | [Battlefield 1](https://hencheats.vercel.app/#CUSA02429-01.00) |
| 2026-05-24 | ADDED | PPSA07631 | 01.000.000 | [SAROS](https://hencheats.vercel.app/#PPSA07631-01.000.000) |
| 2026-05-23 | ADDED | PPSA09519 | 01.000.011 | [WUCHANG: Fallen Feathers](https://hencheats.vercel.app/#PPSA09519-01.000.011) |
| 2026-05-20 | ADDED | PPSA15304 | 01.001.004 | [METAL GEAR SOLID Δ: SNAKE EATER](https://hencheats.vercel.app/#PPSA15304-01.001.004) |
| 2026-05-19 | ADDED | PPSA10872 | 01.008.000 | [Persona 3 Reload](https://hencheats.vercel.app/#PPSA10872-01.008.000) |
| 2026-05-18 | ADDED | PPSA02530 | 01.200.000 | [PRAGMATA](https://hencheats.vercel.app/#PPSA02530-01.200.000) |
| 2026-05-16 | ADDED | PPSA09259 | 01.006.000 | [Hell is Us](https://hencheats.vercel.app/#PPSA09259-01.006.000) |
| 2026-05-15 | ADDED | PPSA30803 | 02.013.000 | [Resident Evil Requiem](https://hencheats.vercel.app/#PPSA30803-02.013.000) |
| 2026-05-15 | ADDED | PPSA31246 | 02.013.000 | [Resident Evil Requiem](https://hencheats.vercel.app/#PPSA31246-02.013.000) |
| 2026-05-15 | ADDED | PPSA30803 | 01.200.000 | [Resident Evil Requiem](https://hencheats.vercel.app/#PPSA30803-01.200.000) |
| 2026-05-15 | ADDED | PPSA31246 | 01.200.000 | [Resident Evil Requiem](https://hencheats.vercel.app/#PPSA31246-01.200.000) |
| 2026-05-11 | ADDED | PPSA01494 | 01.003.001 | [Borderlands 4](https://hencheats.vercel.app/#PPSA01494-01.003.001) |
| 2026-05-08 | ADDED | PPSA26679 | 01.003.000 | [NINJA GAIDEN 2 Black](https://hencheats.vercel.app/#PPSA26679-01.003.000) |
| 2026-05-07 | ADDED | PPSA08709 | 01.006.000 | [Silent Hill 2](https://hencheats.vercel.app/#PPSA08709-01.006.000) |
| 2026-05-03 | ADDED | PPSA23226 | 01.000.016 | [Black Myth: Wukong](https://hencheats.vercel.app/#PPSA23226-01.000.016) |

</details>

<details>
<summary><b>April 2026</b></summary>

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-04-30 | ADDED | PPSA03098 | 01.000.001 | [Dead Island 2](https://hencheats.vercel.app/#PPSA03098-01.000.001) |
| 2026-04-30 | ADDED | PPSA03098 | 01.000.010 | [Dead Island 2](https://hencheats.vercel.app/#PPSA03098-01.000.010) |
| 2026-04-30 | UPDATE | PPSA03099 | 01.000.001 | [Dead Island 2](https://hencheats.vercel.app/#PPSA03099-01.000.001) |
| 2026-04-28 | ADDED | PPSA21704 | 01.041.000 | [Kingdom Come: Deliverance II](https://hencheats.vercel.app/#PPSA21704-01.041.000) |
| 2026-04-24 | ADDED | PPSA28329 | 01.005.000 | [RoboCop: Rogue City - Unfinished Business](https://hencheats.vercel.app/#PPSA28329-01.005.000) |
| 2026-04-21 | ADDED | PPSA14251 | 01.006.000 | [Mafia: The Old Country](https://hencheats.vercel.app/#PPSA14251-01.006.000) |
| 2026-04-21 | ADDED | PPSA14299 | 01.006.000 | [Mafia: The Old Country](https://hencheats.vercel.app/#PPSA14299-01.006.000) |
| 2026-04-18 | ADDED | PPSA20447 | 01.000.020 | [The First Berserker: Khazan](https://hencheats.vercel.app/#PPSA20447-01.000.020) |
| 2026-04-18 | UPDATE | PPSA01593 | 01.000.010 | [Hogwarts Legacy](https://hencheats.vercel.app/#PPSA01593-01.000.010) |
| 2026-04-18 | UPDATE | PPSA01716 | 01.000.027 | [Need for Speed Unbound](https://hencheats.vercel.app/#PPSA01716-01.000.027) |
| 2026-04-18 | UPDATE | PPSA06389 | 01.000.000 | [System Shock](https://hencheats.vercel.app/#PPSA06389-01.000.000) |
| 2026-04-18 | UPDATE | PPSA20612 | 01.000.000 | [Dragon Quest III HD-2D Remake](https://hencheats.vercel.app/#PPSA20612-01.000.000) |
| 2026-04-18 | UPDATE | PPSA21159 | 01.001.000 | [Silent Hill f](https://hencheats.vercel.app/#PPSA21159-01.001.000) |
| 2026-04-18 | UPDATE | PPSA22327 | 01.685.672 | [Forza Horizon 5](https://hencheats.vercel.app/#PPSA22327-01.685.672) |
| 2026-04-18 | UPDATE | PPSA10053 | 01.005.000 | [Banishers: Ghosts of New Eden](https://hencheats.vercel.app/#PPSA10053-01.005.000) |
| 2026-04-16 | UPDATE | PPSA17599 | 01.400.000 | [Clair Obscur: Expedition 33](https://hencheats.vercel.app/#PPSA17599-01.400.000) |
| 2026-04-16 | UPDATE | PPSA22327 | 01.685.672 | [Forza Horizon 5](https://hencheats.vercel.app/#PPSA22327-01.685.672) |
| 2026-04-13 | ADDED | PPSA22327 | 01.685.672 | [Forza Horizon 5](https://hencheats.vercel.app/#PPSA22327-01.685.672) |
| 2026-04-13 | ADDED | PPSA26344 | 01.008.000 | [Ghost of Yotei](https://hencheats.vercel.app/#PPSA26344-01.008.000) |
| 2026-04-12 | ADDED | PPSA26786 | 01.009.000 | [Indiana Jones and The Great Circle](https://hencheats.vercel.app/#PPSA26786-01.009.000) |
| 2026-04-10 | ADDED | PPSA24096 | 01.006.000 | [Cronos: The New Dawn](https://hencheats.vercel.app/#PPSA24096-01.006.000) |
| 2026-04-08 | ADDED | PPSA25381 | 01.000.000 | [ELDEN RING NIGHTREIGN](https://hencheats.vercel.app/#PPSA25381-01.000.000) |
| 2026-04-07 | ADDED | PPSA20560 | 01.009.000 | [DOOM: The Dark Ages](https://hencheats.vercel.app/#PPSA20560-01.009.000) |
| 2026-04-03 | ADDED | PPSA01576 | 01.011.000 | [Avatar: Frontiers of Pandora](https://hencheats.vercel.app/#PPSA01576-01.011.000) |
| 2026-04-03 | UPDATE | PPSA21159 | 01.001.000 | [SILENT HILL f](https://hencheats.vercel.app/#PPSA21159-01.001.000) |

</details>

<details>
<summary><b>March 2026</b></summary>

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-03-30 | ADDED | PPSA21159 | 01.001.000 | [Silent Hill f](https://hencheats.vercel.app/#PPSA21159-01.001.000) |
| 2026-03-28 | ADDED | PPSA16388 | 01.017.000 | [Hitman: World of Assassination](https://hencheats.vercel.app/#PPSA16388-01.017.000) |
| 2026-03-27 | UPDATE | PPSA08260 | 01.003.001 | [Star Wars Outlaws](https://hencheats.vercel.app/#PPSA08260-01.003.001) |
| 2026-03-27 | UPDATE | PPSA17599 | 01.400.000 | [Clair Obscur: Expedition 33](https://hencheats.vercel.app/#PPSA17599-01.400.000) |
| 2026-03-25 | ADDED | PPSA17599 | 01.400.000 | [Clair Obscur: Expedition 33](https://hencheats.vercel.app/#PPSA17599-01.400.000) |
| 2026-03-24 | UPDATE | PPSA03977 | 04.040.100 | [The Witcher 3: Wild Hunt: Complete Edition](https://hencheats.vercel.app/#PPSA03977-04.040.100) |
| 2026-03-24 | ADDED | PPSA01342 | 01.000.000 | [Demon's Souls](https://hencheats.vercel.app/#PPSA01342-01.000.000) |
| 2026-03-24 | ADDED | PPSA01473 | 01.000.000 | [Ratchet & Clank: Rift Apart](https://hencheats.vercel.app/#PPSA01473-01.000.000) |
| 2026-03-24 | ADDED | PPSA01473 | 01.004.001 | [Ratchet & Clank: Rift Apart](https://hencheats.vercel.app/#PPSA01473-01.004.001) |
| 2026-03-24 | ADDED | PPSA01556 | 01.001.000 | [Resident Evil Village](https://hencheats.vercel.app/#PPSA01556-01.001.000) |
| 2026-03-24 | ADDED | PPSA03396 | 01.000.000 | [The Last of Us: Part I](https://hencheats.vercel.app/#PPSA03396-01.000.000) |
| 2026-03-24 | ADDED | PPSA08666 | 01.040.000 | [Final Fantasy VII Rebirth](https://hencheats.vercel.app/#PPSA08666-01.040.000) |
| 2026-03-24 | ADDED | PPSA08710 | 01.000.000 | [SILENT HILL 2](https://hencheats.vercel.app/#PPSA08710-01.000.000) |  |
| 2026-03-24 | ADDED | PPSA15210 | 01.000.000 | [DRAGON BALL: Sparking! ZERO](https://hencheats.vercel.app/#PPSA15210-01.000.000) |
| 2026-03-24 | ADDED | PPSA21564 | 01.007.000 | [Astro Bot](https://hencheats.vercel.app/#PPSA21564-01.007.000) |
| 2026-03-24 | ADDED | PPSA23226 | 01.000.010 | [Black Myth: Wukong](https://hencheats.vercel.app/#PPSA23226-01.000.010) |
| 2026-03-24 | ADDED | PPSA07412 | 01.000.000 | [Resident Evil 4](https://hencheats.vercel.app/#PPSA07412-01.000.000) |
| 2026-03-24 | UPDATE | PPSA02745 | 01.000.004 | [Tales of Arise](https://hencheats.vercel.app/#PPSA02745-01.000.004) |
| 2026-03-24 | UPDATE | PPSA03952 | 01.000.004 | [Resident Evil 3](https://hencheats.vercel.app/#PPSA03952-01.000.004) |
| 2026-03-24 | UPDATE | PPSA03977 | 04.000.000 | [The Witcher 3: Wild Hunt: Complete Edition](https://hencheats.vercel.app/#PPSA03977-04.000.000) |
| 2026-03-24 | UPDATE | PPSA04288 | 01.000.003 | [Resident Evil 2](https://hencheats.vercel.app/#PPSA04288-01.000.003) |
| 2026-03-24 | UPDATE | PPSA07411 | 01.100.000 | [Resident Evil 4](https://hencheats.vercel.app/#PPSA07411-01.100.000) |
| 2026-03-24 | UPDATE | PPSA07412 | 01.000.000 | [Resident Evil 4](https://hencheats.vercel.app/#PPSA07412-01.000.000) |
| 2026-03-24 | UPDATE | PPSA09663 | 01.000.000 | [Dragon's Dogma 2](https://hencheats.vercel.app/#PPSA09663-01.000.000) |
| 2026-03-23 | ADDED | PPSA08260 | 01.003.001 | [Star Wars Outlaws](https://hencheats.vercel.app/#PPSA08260-01.003.001) |
| 2026-03-18 | ADDED | PPSA03977 | 04.040.100 | [The Witcher 3: Wild Hunt: Complete Edition](https://hencheats.vercel.app/#PPSA03977-04.040.100) |
| 2026-03-13 | ADDED | PPSA15656 | 01.000.000 | [Disney Epic Mickey: Rebrushed](https://hencheats.vercel.app/#PPSA15656-01.000.000) |
| 2026-03-13 | ADDED | PPSA15657 | 01.000.000 | [Disney Epic Mickey: Rebrushed](https://hencheats.vercel.app/#PPSA15657-01.000.000) |
| 2026-03-12 | ADDED | CUSA02420 | 01.02 | [Darksiders II: Deathinitive Edition](https://hencheats.vercel.app/#CUSA02420-01.02) |
| 2026-03-12 | ADDED | CUSA11275 | 02.60 | [Horizon Chase Turbo](https://hencheats.vercel.app/#CUSA11275-02.60) |
| 2026-03-12 | ADDED | CUSA09263 | 01.01 | [Devil May Cry: HD Collection](https://hencheats.vercel.app/#CUSA09263-01.01) |
| 2026-03-12 | ADDED | CUSA07411 | 01.35 | [God of War (2018)](https://hencheats.vercel.app/#CUSA07411-01.35) |
| 2026-03-12 | ADDED | CUSA07410 | 01.35 | [God of War (2018)](https://hencheats.vercel.app/#CUSA07410-01.35) |
| 2026-03-12 | ADDED | CUSA07408 | 01.35 | [God of War (2018)](https://hencheats.vercel.app/#CUSA07408-01.35) |
| 2026-03-12 | ADDED | CUSA05350 | 01.50 | [Dragon Ball: Xenoverse 2](https://hencheats.vercel.app/#CUSA05350-01.50) |
| 2026-03-12 | ADDED | CUSA13275 | 01.27 | [Doom Eternal](https://hencheats.vercel.app/#CUSA13275-01.27) |
| 2026-03-12 | ADDED | CUSA04885 | 01.01 | [Resident Evil 4](https://hencheats.vercel.app/#CUSA04885-01.01) |
| 2026-03-12 | ADDED | CUSA03980 | 01.02 | [BioShock: The Collection](https://hencheats.vercel.app/#CUSA03980-01.02) |
| 2026-03-12 | ADDED | CUSA01623 | 01.02 | [God of War III Remastered](https://hencheats.vercel.app/#CUSA01623-01.02) |
| 2026-03-12 | ADDED | CUSA01067 | 01.00 | [Resident Evil HD Remaster](https://hencheats.vercel.app/#CUSA01067-01.00) |
| 2026-03-12 | ADDED | CUSA00556 | 01.11 | [The Last of Us: Remastered](https://hencheats.vercel.app/#CUSA00556-01.11) |
| 2026-03-12 | ADDED | CUSA00552 | 01.11 | [The Last of Us: Remastered](https://hencheats.vercel.app/#CUSA00552-01.11) |
| 2026-03-12 | ADDED | CUSA00462 | 01.08 | [Far Cry 4](https://hencheats.vercel.app/#CUSA00462-01.08) |
| 2026-03-12 | ADDED | CUSA03986 | 01.02 | [BioShock: The Collection](https://hencheats.vercel.app/#CUSA03986-01.02) |
| 2026-03-12 | ADDED | CUSA13801 | 01.06 | [Sekiro: Shadows Die Twice](https://hencheats.vercel.app/#CUSA13801-01.06) |
| 2026-03-12 | UPDATE | CUSA01715 | 01.02 | [God of War III Remastered](https://hencheats.vercel.app/#CUSA01715-01.02) |
| 2026-03-12 | UPDATE | CUSA04762 | 01.25 | [Call of Duty: Infinite Warfare](https://hencheats.vercel.app/#CUSA04762-01.25) |
| 2026-03-12 | UPDATE | CUSA05369 | 01.25 | [Call of Duty: Infinite Warfare](https://hencheats.vercel.app/#CUSA05369-01.25) |
| 2026-03-12 | UPDATE | CUSA07410 | 01.36 | [God of War (2018)](https://hencheats.vercel.app/#CUSA07410-01.36) |
| 2026-03-12 | UPDATE | CUSA16261 | 01.08 | [Blasphemous](https://hencheats.vercel.app/#CUSA16261-01.08) |
| 2026-03-12 | UPDATE | CUSA16275 | 01.08 | [Blasphemous](https://hencheats.vercel.app/#CUSA16275-01.08) |
| 2026-03-12 | UPDATE | CUSA18008 | 01.13 | [Resident Evil Village](https://hencheats.vercel.app/#CUSA18008-01.13) |
| 2026-03-12 | UPDATE | CUSA18017 | 01.13 | [Resident Evil Village](https://hencheats.vercel.app/#CUSA18017-01.13) |
| 2026-03-12 | UPDATE | CUSA24853 | 02.08 | [Kena: Bridge of Spirits](https://hencheats.vercel.app/#CUSA24853-02.08) |
| 2026-03-12 | ADDED | CUSA15240 | 01.09 | [Call of Duty: Modern Warfare](https://hencheats.vercel.app/#CUSA15240-01.09) |
| 2026-03-12 | ADDED | CUSA15280 | 01.22 | [Call of Duty: Modern Warfare](https://hencheats.vercel.app/#CUSA15280-01.22) |
| 2026-03-12 | ADDED | CUSA50617 | 01.20 | [ELDEN RING NIGHTREIGN](https://hencheats.vercel.app/#CUSA50617-01.20) |
| 2026-03-12 | ADDED | PPSA09663 | 01.000.000 | [Dragon's Dogma 2](https://hencheats.vercel.app/#PPSA09663-01.000.000) |
| 2026-03-12 | UPDATE | CUSA03388 | 01.15 | [Dark Souls III](https://hencheats.vercel.app/#CUSA03388-01.15) |
| 2026-03-12 | UPDATE | CUSA04437 | 01.01 | [Resident Evil 5](https://hencheats.vercel.app/#CUSA04437-01.01) |
| 2026-03-12 | UPDATE | CUSA07820 | 01.09 | [The Last of Us: Part II](https://hencheats.vercel.app/#CUSA07820-01.09) |
| 2026-03-12 | UPDATE | CUSA10249 | 01.09 | [The Last of Us: Part II](https://hencheats.vercel.app/#CUSA10249-01.09) |
| 2026-03-12 | UPDATE | CUSA36582 | 01.40 | [Prince of Persia: The Lost Crown](https://hencheats.vercel.app/#CUSA36582-01.40) |
| 2026-03-12 | UPDATE | CUSA39420 | 01.04 | [Hollow Knight: Silksong](https://hencheats.vercel.app/#CUSA39420-01.04) |
| 2026-03-12 | UPDATE | PPSA03396 | 01.003.000 | [The Last of Us: Part I](https://hencheats.vercel.app/#PPSA03396-01.003.000) |
| 2026-03-12 | UPDATE | PPSA10662 | 01.001.030 | [The Last of Us: Part II Remastered](https://hencheats.vercel.app/#PPSA10662-01.001.030) |
| 2026-03-12 | UPDATE | PPSA15508 | 01.001.030 | [The Last of Us: Part II Remastered](https://hencheats.vercel.app/#PPSA15508-01.001.030) |
| 2026-03-11 | ADDED | PPSA10067 | 01.004.001 | [Prince of Persia: The Lost Crown](https://hencheats.vercel.app/#PPSA10067-01.004.001) |
| 2026-03-11 | ADDED | PPSA10528 | 01.004.001 | [Prince of Persia: The Lost Crown](https://hencheats.vercel.app/#PPSA10528-01.004.001) |
| 2026-03-07 | ADDED | PPSA04813 | 01.000.000 | [Outcast: A New Beginning](https://hencheats.vercel.app/#PPSA04813-01.000.000) |
| 2026-03-07 | ADDED | PPSA04814 | 01.000.000 | [Outcast: A New Beginning](https://hencheats.vercel.app/#PPSA04814-01.000.000) |
| 2026-03-02 | ADDED | CUSA11260 | 01.13 | [Death Stranding](https://hencheats.vercel.app/#CUSA11260-01.13) |

</details>

<details>
<summary><b>February 2026</b></summary>

| Date | Status | ID | Version | Title |
|-|-|-|-|-|
| 2026-02-28 | ADDED | PPSA18259 | 01.000.000 | [Dead Rising Deluxe Remaster](https://hencheats.vercel.app/#PPSA18259-01.000.000) |
| 2026-02-26 | ADDED | PPSA04609 | 01.017.000 | [Elden Ring](https://hencheats.vercel.app/#PPSA04609-01.017.000) |
| 2026-02-25 | ADDED | PPSA01284 | 03.000.004 | [Returnal](https://hencheats.vercel.app/#PPSA01284-03.000.004) |
| 2026-02-23 | ADDED | CUSA54714 | 01.13 | [Yakuza Kiwami 3 & Dark Ties](https://hencheats.vercel.app/#CUSA54714-01.13) |
| 2026-02-21 | ADDED | PPSA15210 | 01.000.000 | [DRAGON BALL: Sparking! ZERO](https://hencheats.vercel.app/#PPSA15210-01.000.000) |
| 2026-02-21 | ADDED | PPSA15211 | 01.000.000 | [DRAGON BALL: Sparking! ZERO](https://hencheats.vercel.app/#PPSA15211-01.000.000) |
| 2026-02-19 | ADDED | PPSA09664 | 03.000.000 | [Dragon's Dogma 2](https://hencheats.vercel.app/#PPSA09664-03.000.000) |
| 2026-02-11 | ADDED | PPSA01390 | 01.000.000 | [Dragon Age™: The Veilguard Deluxe Edition](https://hencheats.vercel.app/#PPSA01390-01.000.000) |
| 2026-02-05 | ADDED | PPSA02525 | 01.009.000 | [Tormented Souls](https://hencheats.vercel.app/#PPSA02525-01.009.000) |

</details>

## Notes
### 2026-08-08
Fixed some bugs with my parser, merger and exporter that resulted in some files losing data along the way.
These fixed updated 92 cheat files and hopefully made them work correctly if they didn't before.

### 2026-07-21
Big improvements to the website:
- Sorting options - Sort by A-Z, Z-A, New-Old, Old-New.
- New cheats get a `NEW`-badge.
- Entries now supports notes. This will be the main way to convey information going forward regarding cheats and anything related to it.
- Cheats can now be downloaded directly from the website. Browse for a game, enter it's card, and download just the cheat file you want. To download the whole collection you still have to go to [GitHub](https://github.com/TeeKay87/HEN-Cheats-Collection).
- You can now report cheat issues directly from the game-cards on the webiste.

### 2026-07-11
Fixed a couple of things.
- All involved cheat creators are now credited when cheat files are merged. Previously a bug caused only the creator of the first file to be credited.
- Merged cheats are now sorted by source-file. Cheats from file 1 are forted first, then cheats from file 2 and so on. 
- Fixed a bug that aggressively marked some cheats as duplicates and skipped writing them to file. Fixing this has resulted in alot more cheats to be available.

These fixes made changes to 3998 files.

### 2026-02-17
Added lots of new cheats.
Added new cheat sources.

Major rework of my HEN Cheats Manager to make it able to merge cheatfiles belonging to same ID/Version combo into a single file. This change will make more cheats available for games that have multiple files from multiple creators as etaHEN only can use one cheat of each file format at a time.

### 2026-02-05
Collection created with new version of my HEN Cheats Manager.

Added `Yharnam` cheats.

Some of the official cheats, and cheats from other sources, are missing tags in their json and xml formatting, and some have other issues. HEN-CM now tries to repair these broken files to hopefully make more cheats work as intended.

As of 2026-02-26, my collection has support for `2364` games and updates, whereas the official etaHEN Cheats repository has cheats for `2130`.

### 2026-01-31
Added the first iteration of the collection containing cheats for 2284 different games and versions
